import reactRefreshPlugin from 'eslint-plugin-react-refresh';
import perfectionistPlugin from 'eslint-plugin-perfectionist';
import globals from 'globals';
import jsEslint from '@eslint/js';
import tsEslint from 'typescript-eslint';
import reactHooksPlugin from 'eslint-plugin-react-hooks';
import reactPlugin from 'eslint-plugin-react';
import prettierPlugin from 'eslint-plugin-prettier';
import tailwindPlugin from 'eslint-plugin-tailwindcss';
import queryPlugin from '@tanstack/eslint-plugin-query';
import prettierConfig from 'eslint-config-prettier';

export default tsEslint.config(
    {
        ignores: [
            'node_modules',
            'generated',
            'dist',
            'orval.config.ts',
            'vite.config.ts',
            'vitest.config.ts',
            'tailwind.config.ts',
            'postcss.config.cjs',
            'eslint.config.mjs',
            'src/test',
        ],
    },
    {
        extends: [
            jsEslint.configs.recommended,
            ...tsEslint.configs.strictTypeChecked,
            ...tsEslint.configs.stylisticTypeChecked,
            reactPlugin.configs.flat.recommended,
            reactPlugin.configs.flat['jsx-runtime'],
            ...tailwindPlugin.configs['flat/recommended'],
            ...queryPlugin.configs['flat/recommended'],
            prettierConfig,
        ],
        files: ['**/*.{ts,tsx}'],
        languageOptions: {
            ecmaVersion: 'latest',
            globals: globals.browser,
            parser: tsEslint.parser,
            parserOptions: {
                ecmaVersion: 'latest',
                sourceType: 'module',
                tsconfigRootDir: import.meta.dirname,
                project: ['./tsconfig.json', './tsconfig.node.json', './tsconfig.app.json'],
            },
        },
        plugins: {
            'react-refresh': reactRefreshPlugin,
            'react-hooks': reactHooksPlugin,
            perfectionist: perfectionistPlugin,
            prettier: prettierPlugin,
            tailwindcss: tailwindPlugin,
        },
        rules: {
            ...reactHooksPlugin.configs.recommended.rules,
            ...prettierPlugin.configs.recommended.rules,
            ...queryPlugin.configs.recommended.rules,
            ...prettierConfig.rules,

            'perfectionist/sort-imports': [
                2,
                {
                    type: 'natural',
                    order: 'asc',
                },
            ],
            'react-refresh/only-export-components': [2, {allowConstantExport: true}],

            '@typescript-eslint/consistent-type-imports': [2],
            '@typescript-eslint/no-unused-vars': [2, {argsIgnorePattern: '^_', ignoreRestSiblings: true}],
            '@typescript-eslint/no-misused-promises': [1],
            '@typescript-eslint/no-floating-promises': [1],
            '@typescript-eslint/no-deprecated': [1],
            '@typescript-eslint/restrict-template-expressions': [1],
            '@typescript-eslint/unbound-method': [0],

            'react/display-name': [0],
            'react/prop-types': [0],

            'no-restricted-imports': [
                'error',
                {
                    paths: [
                        {
                            name: 'react',
                            importNames: ['default'],
                            message: "Dont use 'import React from 'react''.",
                        },
                        {
                            name: 'react-router',
                            message: 'Please use import from react-router-dom instead.',
                        },
                        {
                            name: 'antd',
                            importNames: ['notification', 'message'],
                            message: 'Please use `const {notification, message} = useApp();` instead.',
                        },
                    ],
                },
            ],

            'no-console': [2],
        },
        settings: {
            react: {
                version: 'detect',
            },
            tailwindcss: {
                config: 'tailwind.config.ts',
                whitelist: ['active'],
            },
        },
    },
);
