import type {Config} from 'tailwindcss';
import plugin from 'tailwindcss/plugin';

import {colors} from './src/libs/theme';

const gazpromColors = Object.entries(colors).reduce((acc, [key, color]) => {
    return key.startsWith('gazprom')
        ? {
              ...acc,
              [key.replaceAll('_', '-')]: color,
          }
        : acc;
}, {});

export default {
    content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
    safelist: Object.keys(gazpromColors)
        .map(color => [`bg-${color}`, `text-${color}`, `fill-${color}`])
        .flat(1),
    theme: {
        extend: {
            fontSize: {
                xxs: ['10px', '14px'],
            },
            colors: {
                // rgb(var(--color-NAME) / <alpha-value>)
                primary: 'rgb(var(--color-primary) / <alpha-value>)',
                'primary-100': 'rgb(var(--color-primary-100) / <alpha-value>)',
                'primary-200': 'rgb(var(--color-primary-200) / <alpha-value>)',
                'primary-300': 'rgb(var(--color-primary-300) / <alpha-value>)',

                secondary: 'rgb(var(--color-secondary) / <alpha-value>)',
                bg: 'rgb(var(--color-bg) / <alpha-value>)',
                tone: 'rgb(var(--color-tone) / <alpha-value>)',
                dark: 'rgb(var(--color-dark) / <alpha-value>)',

                accent: 'rgb(var(--color-accent) / <alpha-value>)',
                'accent-light': 'rgb(var(--color-accent-light) / <alpha-value>)',

                success: 'rgb(var(--color-success) / <alpha-value>)',
                caution: 'rgb(var(--color-caution) / <alpha-value>)',
                warning: 'rgb(var(--color-warning) / <alpha-value>)',
                alert: 'rgb(var(--color-alert) / <alpha-value>)',
                system: 'rgb(var(--color-system) / <alpha-value>)',
                description: 'rgb(var(--color-description) / <alpha-value>)',

                ...gazpromColors,
            },
            aspectRatio: {
                '4/3': '4 / 3',
                '3/4': '3 / 4',
            },
        },
    },
    variants: {
        extend: {},
    },
    plugins: [
        plugin(function ({addUtilities, addComponents, theme, addVariant}) {
            const newUtilities = {
                '.h-screen-safe': {
                    height: 'calc(100vh - env(safe-area-inset-top) - env(safe-area-inset-bottom))',
                    'padding-left': 'env(safe-area-inset-left)',
                    'padding-right': 'env(safe-area-inset-right)',
                },
                '.fill-transparent': {
                    '& svg': {
                        fill: 'transparent !important',
                        stroke: 'currentColor !important',
                    },
                },
                '.stroke-transparent': {
                    '& svg': {
                        fill: 'currentColor !important',
                        stroke: 'transparent !important',
                    },
                },
                '.full-svg': {
                    '& > svg': {
                        width: '100%',
                        height: '100%',
                    },
                },
                '.container-fluid': {
                    width: '100%',
                    paddingLeft: '1.5rem',
                    paddingRight: '1.5rem',
                },
            };

            addComponents({
                '.card': {
                    boxShadow: theme('boxShadow.lg'),
                    backgroundColor: theme('colors.white'),
                    borderRadius: theme('borderRadius.lg'),
                },
            });

            addUtilities(newUtilities);

            new Array(100).fill(0).forEach((_, idx) => {
                addVariant(`child-${idx + 1}`, `&:nth-child(${idx + 1})`);
            });
        }),
    ],
} satisfies Config;
