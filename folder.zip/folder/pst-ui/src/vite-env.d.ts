/// <reference types="vite/client" />
/// <reference types="vite-plugin-svgr/client" />

declare const _SYSTEM: string;
declare const _VERSION: string;
declare const _BUILD_DATE: string;
