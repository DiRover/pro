import {RoleDtoRole} from '@generated/model/roleDtoRole.ts';

// Администрирование
export const VIEW_ADMINISTRATION = [RoleDtoRole.ADMIN];

// Мониторинг
export const MANAGE_MONITORING = [
    RoleDtoRole.OPERATOR,
    RoleDtoRole.DISPATCHER,
    RoleDtoRole.MODERATOR,
    RoleDtoRole.SECURITY_OFFICER,
];
export const VIEW_MONITORING_ACCESS_LOG = [RoleDtoRole.SECURITY_OFFICER];
export const VIEW_MONITORING = Array.from(
    new Set([...MANAGE_MONITORING, ...VIEW_MONITORING_ACCESS_LOG, RoleDtoRole.TECHNICAL_SUPPORT]),
);

// Аналитика
export const MANAGE_ANALYTIC_ZONE = [
    RoleDtoRole.OPERATOR,
    RoleDtoRole.DISPATCHER,
    RoleDtoRole.MODERATOR,
    RoleDtoRole.SECURITY_OFFICER,
];
export const VIEW_ANALYTIC_ZONE = Array.from(new Set([...MANAGE_ANALYTIC_ZONE, RoleDtoRole.TECHNICAL_SUPPORT]));
export const VIEW_ANALYTIC_VIOLATIONS = [RoleDtoRole.SECURITY_OFFICER];
export const VIEW_ANALYTIC = Array.from(new Set([...VIEW_ANALYTIC_ZONE, ...VIEW_ANALYTIC_VIOLATIONS]));

// Оповещения
export const VIEW_NOTIFICATION_LIST = [
    RoleDtoRole.OPERATOR,
    RoleDtoRole.DISPATCHER,
    RoleDtoRole.MODERATOR,
    RoleDtoRole.SECURITY_OFFICER,
    RoleDtoRole.TECHNICAL_SUPPORT,
];
export const VIEW_NOTIFICATION_BELL = Array.from(new Set([...VIEW_NOTIFICATION_LIST, RoleDtoRole.ADMIN]));

// Настройки объекта
export const MANAGE_SUBJECT_CONFIG_POLYGONS = [
    RoleDtoRole.OPERATOR,
    RoleDtoRole.MODERATOR,
    RoleDtoRole.SECURITY_OFFICER,
    RoleDtoRole.DISPATCHER,
];
export const MANAGE_SUBJECT_CONFIG_ADMISSION = MANAGE_SUBJECT_CONFIG_POLYGONS;
export const MANAGE_SUBJECT_CONFIG_ORGS = MANAGE_SUBJECT_CONFIG_POLYGONS;

export const VIEW_SUBJECT_CONFIG = Array.from(
    new Set([
        ...MANAGE_SUBJECT_CONFIG_POLYGONS,
        ...MANAGE_SUBJECT_CONFIG_ADMISSION,
        ...MANAGE_SUBJECT_CONFIG_ORGS,
        RoleDtoRole.TECHNICAL_SUPPORT,
    ]),
);

// Управление доступом
export const MANAGE_BLACKLIST = [RoleDtoRole.SECURITY_OFFICER];
export const MANAGE_ACCESS_CONTROL = [RoleDtoRole.SECURITY_OFFICER, RoleDtoRole.PASS_OPERATOR];
export const VIEW_ACCESS_CONTROL = Array.from(new Set([...MANAGE_ACCESS_CONTROL, RoleDtoRole.TECHNICAL_SUPPORT]));

// Журнал доступа
export const VIEW_ACCESS_LOG = [
    RoleDtoRole.MODERATOR,
    RoleDtoRole.SECURITY_OFFICER,
    RoleDtoRole.PASS_OPERATOR,
    RoleDtoRole.TECHNICAL_SUPPORT,
];

// Настройки
export const MANAGE_SETTING = [RoleDtoRole.MODERATOR, RoleDtoRole.SECURITY_OFFICER, RoleDtoRole.PASS_OPERATOR];
export const VIEW_SETTING = Array.from(new Set([...MANAGE_SETTING, RoleDtoRole.TECHNICAL_SUPPORT]));

// Список оповещений
export const VIEW_LIST_OF_NOTIFICATIONS = [
    RoleDtoRole.SECURITY_OFFICER,
    RoleDtoRole.ADMIN,
    RoleDtoRole.MODERATOR,
    RoleDtoRole.OPERATOR,
    RoleDtoRole.DISPATCHER,
    RoleDtoRole.TECHNICAL_SUPPORT,
];

// Инструменты
export const VIEW_TOOLS = [RoleDtoRole.OPERATOR, RoleDtoRole.DISPATCHER];

// Global Select - выбор объекта
export const VIEW_GLOBAL_SELECT = [
    RoleDtoRole.OPERATOR,
    RoleDtoRole.DISPATCHER,
    RoleDtoRole.MODERATOR,
    RoleDtoRole.SECURITY_OFFICER,
    RoleDtoRole.PASS_OPERATOR,
    RoleDtoRole.TECHNICAL_SUPPORT,
];

export const DOWNLOAD_REPORT = [
    RoleDtoRole.MODERATOR,
    RoleDtoRole.OPERATOR,
    RoleDtoRole.SECURITY_OFFICER,
    RoleDtoRole.TECHNICAL_SUPPORT,
];
export const DOWNLOAD_REPORT_WITH_PERSONAL_DATA = [RoleDtoRole.SECURITY_OFFICER, RoleDtoRole.TECHNICAL_SUPPORT];
