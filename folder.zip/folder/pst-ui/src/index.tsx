/**
 * Created by VIATKIN A.A. on 11.04.2022
 */

import type {ConfigProviderProps} from 'antd/es/config-provider';

import {StyleProvider} from '@ant-design/cssinjs';
import {QueryClientProvider} from '@tanstack/react-query';
import {ReactQueryDevtools} from '@tanstack/react-query-devtools';
import {ConfigProvider} from 'antd';
import ruRU from 'antd/es/locale/ru_RU';
import * as dayjs from 'dayjs';
import 'dayjs/locale/ru';
import duration from 'dayjs/plugin/duration';
import isBetween from 'dayjs/plugin/isBetween';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import localizedFormat from 'dayjs/plugin/localizedFormat';
import minMax from 'dayjs/plugin/minMax';
import relativeTime from 'dayjs/plugin/relativeTime';
import timezone from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';
import {StrictMode, Suspense, lazy} from 'react';
import {createRoot} from 'react-dom/client';
import {RecoilRoot} from 'recoil';

import AppWrapper from './components/Utils/AppWrapper.tsx';
import BodyPortal from './components/Utils/BodyPortal.tsx';
import SuspenseLoader from './components/Utils/SuspenseLoader/SuspenseLoader.tsx';
import './global.css';
import {queryClient} from '@libs/queryClient.ts';
import {theme} from '@libs/theme.ts';
import {validateMessages} from '@libs/validateMessages.ts';
import RouterWrapper from './router/RouterWrapper.tsx';

dayjs.extend(relativeTime);
dayjs.extend(localizedFormat);
dayjs.extend(isBetween);
dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);
dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(duration);
dayjs.extend(minMax);
dayjs.locale('ru');

const container = document.getElementById('app');
// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
const root = createRoot(container!);

const configProviderForm: Required<ConfigProviderProps>['form'] = {colon: false, validateMessages};

// eslint-disable-next-line react-refresh/only-export-components
const Messages = lazy(() => import('./components/Feedback/Messages.tsx'));

root.render(
    <StrictMode>
        <RecoilRoot>
            <QueryClientProvider client={queryClient}>
                <ConfigProvider form={configProviderForm} locale={ruRU} theme={theme}>
                    <AppWrapper>
                        <StyleProvider hashPriority="high">
                            <RouterWrapper />

                            <Suspense fallback={<SuspenseLoader />}>
                                <Messages />
                            </Suspense>
                        </StyleProvider>
                    </AppWrapper>
                </ConfigProvider>

                <BodyPortal>
                    <ReactQueryDevtools />
                </BodyPortal>
            </QueryClientProvider>
        </RecoilRoot>
    </StrictMode>,
);
