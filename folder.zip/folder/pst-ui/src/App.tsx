/**
 * Created by VIATKIN A.A. on 11.04.2022
 */

// eslint-disable-next-line no-restricted-imports
import {notification} from 'antd';
import {Suspense, lazy} from 'react';
import {Outlet, useNavigation} from 'react-router-dom';

import {APINotificationCtx} from './components/Utils/apiNotificationCtx.ts';
import Meta from './components/Utils/Meta.tsx';
import SuspenseLoader from './components/Utils/SuspenseLoader/SuspenseLoader.tsx';
import useAuth from './hooks/useAuth.ts';
import useNotificationConfig from './hooks/useNotificationConfig.ts';
import useTokenRefresher from './hooks/useTokenRefresher.ts';

const Header = lazy(() => import('./components/Header/Header.tsx'));

const ReportList = lazy(() => import('./components/Report/ReportList.tsx'));

const {useNotification} = notification;

export function Component() {
    const auth = useAuth();
    const navigation = useNavigation();

    useTokenRefresher();

    const notificationConfig = useNotificationConfig();
    const [apiNotification, contextHolder] = useNotification(notificationConfig);

    return (
        <APINotificationCtx.Provider value={apiNotification}>
            {navigation.state === 'loading' && <SuspenseLoader />}

            {auth && (
                <Suspense fallback={<SuspenseLoader />}>
                    <Header />
                </Suspense>
            )}

            <Outlet />

            {auth && (
                <Suspense fallback={<SuspenseLoader />}>
                    <ReportList />
                </Suspense>
            )}

            <Meta />

            {contextHolder}
        </APINotificationCtx.Provider>
    );
}
