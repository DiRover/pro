import type {Dayjs} from 'dayjs';

declare global {
    type AsDate = Date | Dayjs | string;
}

export {};
