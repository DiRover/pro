import type {ReactNode} from 'react';

import 'axios';

declare module 'axios' {
    export interface AxiosRequestConfig {
        customErrorFormat?(err: unknown): ReactNode;

        noNotification?: boolean;
    }
}
