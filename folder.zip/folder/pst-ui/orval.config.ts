import {defineConfig} from 'orval';

export default defineConfig({
    api: {
        hooks: {
            afterAllFilesWrite: 'prettier --write',
        },
        input: {
            override: {
                transformer: spec => {
                    if (spec.components) {
                        const schemas = spec.components.schemas || {};

                        spec.components.schemas = Object.entries(schemas).reduce((acc, [key, value]) => {
                            if ('properties' in value && value.properties?.content) {
                                value.required ??= [];
                                if (!value.required.includes('content')) {
                                    value.required.push('content');
                                }
                            }

                            return {...acc, [key]: value};
                        }, {});
                    }

                    return spec;
                },
            },
            target: 'http://pst-dev.element-soft.com:8090/v3/api-docs',
        },
        output: {
            clean: true,
            client: 'react-query',
            headers: false,
            mock: false,
            mode: 'tags-split',
            schemas: `generated/model`,
            target: `generated/endpoints`,
            baseUrl: '/webapp',
            override: {
                useNativeEnums: true,
                useDeprecatedOperations: false,
                query: {
                    useQuery: true,
                    useSuspenseQuery: true,
                },
            },
        },
    },
});
