import path from 'path';

import react from '@vitejs/plugin-react';
import {defineConfig} from 'vite';

import svgr from 'vite-plugin-svgr';

const devTarget = 'https://pst-dev.element-soft.com';
const version = process.env.npm_package_version;
const buildDate = Date.now();
const appName = 'PST';
// const appNameDescription = 'Pulse Smart Tracking';

// https://vitejs.dev/config/
export default defineConfig({
    resolve: {
        alias: {
            '@assets': path.resolve(__dirname, './src/assets'),
            '@generated': path.resolve(__dirname, './generated'),
            '@libs': path.resolve(__dirname, './src/libs'),
        },
    },
    plugins: [
        svgr({
            svgrOptions: {
                index: false,
                typescript: false,
                // jsxRuntime: 'automatic',
                memo: true,
                plugins: ['@svgr/plugin-svgo', '@svgr/plugin-jsx'],
                svgoConfig: {
                    plugins: [
                        {
                            name: 'preset-default',
                            params: {
                                overrides: {
                                    removeViewBox: false,
                                },
                            },
                        },
                        {
                            name: 'removeAttrs',
                            params: {
                                attrs: '(fill|stroke|fill-opacity)',
                            },
                        },
                        {
                            name: 'removeDimensions',
                        },
                        {
                            name: 'addAttributesToSVGElement',
                            params: {
                                attributes: [
                                    {
                                        width: '1em',
                                    },
                                    {
                                        height: '1em',
                                    },
                                ],
                            },
                        },
                    ],
                },
            },
        }),
        react(),
    ],
    server: {
        port: 3000,
        proxy: {
            '/webapp': {target: devTarget, changeOrigin: true, secure: true},
            '/avatars': {target: devTarget, changeOrigin: true, secure: true},
            '/geoserver': {target: devTarget, changeOrigin: true, secure: true},
            '/osm': {target: devTarget, changeOrigin: true, secure: true},
            '/report': {changeOrigin: true, secure: true, target: devTarget},
        },
    },
    define: {_SYSTEM: `"${appName}"`, _VERSION: `"${version}"`, _BUILD_DATE: `"${buildDate}"`},
});
