module.exports = {
    plugins: ['prettier-plugin-tailwindcss'],
    tailwindConfig: 'tailwind.config.ts',
    trailingComma: 'all',
    tailwindFunctions: ['clsx'],
    tabWidth: 4,
    printWidth: 120,
    useTabs: false,
    semi: true,
    singleQuote: true,
    jsxSingleQuote: false,
    bracketSpacing: false,
    arrowParens: 'avoid',
};
