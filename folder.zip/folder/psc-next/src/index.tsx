/**
 * Created by VIATKIN A.A. on 29.10.2019
 */

import blue from '@material-ui/core/colors/blue';
import red from '@material-ui/core/colors/red';
import {createTheme, ThemeProvider} from '@material-ui/core/styles';
import ReactDOM from 'react-dom';
import {Provider as ReduxProvider} from 'react-redux';
import {BrowserRouter} from 'react-router-dom';

import App from './App';
import createStore from './store/store';

const store = createStore();

export const mainTheme = createTheme({
    palette: {
        primary: blue,
        secondary: {
            main: '#49ba6f',
        },
        error: red,
    },
    typography: {
        fontFamily: ['Open Sans', 'sans-serif'].join(','),
    },
    overrides: {
        MuiButton: {
            root: {
                textTransform: 'none',
            },
            contained: {
                borderRadius: 8,
                boxShadow: '0px 4px 2px 0 var(--shadow)',
                color: 'white',
                backgroundColor: 'var(--dark-gray)',
            },
            containedSecondary: {
                color: 'white',
            },
        },
        MuiFab: {
            secondary: {
                color: 'white',
            },
        },
    },
});

ReactDOM.render(
    <ReduxProvider store={store}>
        <BrowserRouter>
            <ThemeProvider theme={mainTheme}>
                <App />
            </ThemeProvider>
        </BrowserRouter>
    </ReduxProvider>,
    document.getElementById('app'),
);
