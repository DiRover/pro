/**
 * Created by VIATKIN A.A. on 29.10.2019
 */

import {Global, css} from '@emotion/core';
import blue from '@material-ui/core/colors/blue';
import {Suspense, lazy, memo} from 'react';
import {useDispatch} from 'react-redux';

import AxiosInterceptor from './components/AxiosInterceptor';
import Main from './components/Main';
import SuspenseErrorCatcher from './components/SuspenseErrorCatcher';
import SuspenseLoader from './components/SuspenseLoader';
import {TokenWithAccount} from './entities/Account/types';
import useAuth from './hooks/useAuth';
import useLS from './hooks/useLS';
import Router from './router-next/Router';
import {setAuth, logout} from './store/account/actions';

const Header = lazy(() => import('./components/Header'));
const PickersUtilsProvider = lazy(() => import('./components/PickersUtilsProvider'));

const globalStyle = css`
    :root {
        --header-height: 70px;
        --sub-nav-width: 70px;
        --main: ${blue.A100};
        --main-dark: ${blue['300']};
        --dark-gray: #a1a1a1;
        --gray: #ebebeb;
        --light: #fafafa;
        --light-border: rgba(0, 0, 0, 0.12);
        --text: #25292c;
        --text-light: #fff;
        --shadow: rgba(0, 0, 0, 0.15);
        --gradient: linear-gradient(225deg, #faf0fa, #beebf5);
    }

    html,
    body {
        margin: 0;
        padding: 0;
    }

    body {
        font-family: 'Open Sans', sans-serif;
        background-image: var(--gradient);
        background-attachment: fixed;
    }
`;

const warningMinWidthStyle = css`
    @media screen and (max-width: 1023px) {
        body {
            pointer-events: none;
        }

        #app {
            overflow: hidden;

            &::after {
                content: '🖥 \\00000a \\00000a Пожалуйста, используйте более широкий размер окна';
                position: fixed;
                left: 0;
                right: 0;
                top: 0;
                bottom: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                background-image: var(--gradient);
                color: var(--text);
                white-space: pre-wrap;
                padding: 20px;
                text-align: center;
                z-index: 5000;
            }
        }
    }
`;

const App = memo(() => {
    const isAuth = useAuth();

    const dispatch = useDispatch();
    useLS<TokenWithAccount>('account', token => {
        if (token) {
            dispatch(setAuth(token));
        } else {
            dispatch(
                logout({
                    quiet: true,
                }),
            );
        }
    });

    return (
        <>
            <Global styles={globalStyle} />
            {!_IS_DEV && <Global styles={warningMinWidthStyle} />}

            <AxiosInterceptor />

            {isAuth && (
                <SuspenseErrorCatcher>
                    <Suspense fallback={<SuspenseLoader />}>
                        <Header />
                    </Suspense>
                </SuspenseErrorCatcher>
            )}

            <SuspenseErrorCatcher>
                <Suspense fallback={<SuspenseLoader />}>
                    <PickersUtilsProvider>
                        <Main>
                            <Router />
                        </Main>
                    </PickersUtilsProvider>
                </Suspense>
            </SuspenseErrorCatcher>
        </>
    );
});

App.displayName = 'App';

export default App;
