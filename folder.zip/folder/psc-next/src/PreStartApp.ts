/**
 * Created by VIATKIN A.A. on 09.01.2020
 */

import {clear} from 'idb-keyval';

import {logApp, logError} from './libs/log';
import {register} from './service-worker/register';
import {unregister} from './service-worker/unregister';

const buildDate = localStorage.getItem('build');
if (buildDate !== _BUILD_DATE) {
    unregister(true);
    localStorage.clear();
    sessionStorage.clear();
    // eslint-disable-next-line no-console
    clear()
        .then(() => logApp('Storage cleared!'))
        .catch(e => logError("Cant' clear Storage: %s", e.message));
} else {
    register();
}

localStorage.setItem('build', _BUILD_DATE);
