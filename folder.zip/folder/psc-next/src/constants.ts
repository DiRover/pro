export const MAX_PAGINATION_SIZE = {page: 0, size: 9999};

export const AVAILABLE_UPDATE_TIME = {
    FIVE_MIN: {
        label: '5 минут',
        value: 300000,
    },
    TEN_MIN: {
        label: '10 минут',
        value: 600000,
    },
    THIRTY_MIN: {
        label: '30 минут',
        value: 1800000,
    },
    ONE_HOUR: {
        label: '1 час',
        value: 3600000,
    },
    SIX_HOURS: {
        label: '6 часов',
        value: 21600000,
    },
    TWELVE_HOURS: {
        label: '12 часов',
        value: 43200000,
    },
    ONE_DAY: {
        label: '1 день',
        value: 86400000,
    },
    TWO_DAYS: {
        label: '2 дня',
        value: 172800000,
    },
};

export const UPDATE_TIME_LIST = Object.values(AVAILABLE_UPDATE_TIME);
