/**
 * Created by VIATKIN A.A. on 30.10.2019
 */

declare module '*.png' {
    const value: string;
    export default value;
}

declare module '*.svg' {
    const value: string;
    export default value;
}

declare const _IS_DEV: boolean;
declare const _VERSION: string;
declare const _BUILD_DATE: string;
declare const _SYSTEM: string;
declare const _SYSTEM_SUFFIX: string;
declare const _UNIQUE_STATE: string;

declare const __REDUX_DEVTOOLS_EXTENSION_COMPOSE__: Function;

interface ResizeObserverElement extends Element {
    target: Element;
    contentRect: DOMRect;
}

declare class ResizeObserver {
    constructor(fn: (entries: NodeListOf<ResizeObserverElement>) => void);

    observe(elem: Element, options?: {box?: 'content-box' | 'border-box'}): void;

    unobserve(elem: Element): void;

    disconnect(): void;
}
