export interface Common {
    readonly pk: string;
}

export interface Base extends Common {
    name: string;
    description: string;
    is_active: boolean;
}
