/**
 * Created by VIATKIN A.A. on 23.12.2019
 */

declare const __REDUX_DEVTOOLS_EXTENSION_COMPOSE__: Function;
