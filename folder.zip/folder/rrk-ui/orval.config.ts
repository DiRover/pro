import {defineConfig} from 'orval';

export default defineConfig({
    'rrk-api': {
        input: {
            target: 'http://rrk-dev.element-soft.com:8000/swagger.json',
        },
        output: {
            mode: 'tags-split',
            target: '__generated__/api',
            schemas: '__generated__/model',
            client: 'react-query',
            mock: true,
        },
        hooks: {
            afterAllFilesWrite: 'prettier --write',
        },
    },
});
