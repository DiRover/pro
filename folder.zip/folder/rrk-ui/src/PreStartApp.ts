const buildDate = localStorage.getItem('build');

if (buildDate !== __BUILD_DATE__) {
    localStorage.setItem('build', __BUILD_DATE__);
    if (buildDate && navigator.onLine) window.location.reload();
}

export {};
