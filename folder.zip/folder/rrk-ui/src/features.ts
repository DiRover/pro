export const SELECT_LANGUAGE = false;
