import Header from '@/components/Layout/Header.tsx';
import CompatibleVersionsCheck from '@/components/Utils/CompatibleVersionsCheck.tsx';
import useAutoBack from '@/hooks/useAutoBack.ts';
import {useTokenRotation} from '@/hooks/useTokenRotation.ts';
import Meta from '@/routes/Meta.tsx';
import RouterLoader from '@/routes/RouterLoader.tsx';
import {LoadingOutlined} from '@ant-design/icons';
import {Spin} from 'antd';
import {Outlet, useNavigation} from 'react-router-dom';

export const Component = () => {
    const {state} = useNavigation();
    const {isExpired} = useTokenRotation();
    useAutoBack();

    return (
        <>
            <Header />

            {isExpired ? (
                <Spin indicator={<LoadingOutlined />} spinning tip="Обновляем токен">
                    <div className="grid h-safe-screen place-content-center">
                        <span className="invisible">Обновляем токен</span>
                    </div>
                </Spin>
            ) : (
                <>
                    <Outlet />
                    <CompatibleVersionsCheck />
                </>
            )}

            <Meta />

            {state === 'loading' && <RouterLoader />}
        </>
    );
};
