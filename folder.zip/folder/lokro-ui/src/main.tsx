import AxiosInterceptorAccess from '@/components/Utils/AxiosInterceptorAccess.tsx';
import AxiosInterceptorMessage from '@/components/Utils/AxiosInterceptorMessage.tsx';
import {queryClient} from '@/libs/queryClient.ts';
import {theme} from '@/libs/theme.ts';
import {validateMessagesWithLabels} from '@/libs/validateMessages.ts';
import RouterProviderWrapper from '@/routes/RouterProviderWrapper.tsx';
import {StyleProvider} from '@ant-design/cssinjs';
import {QueryClientProvider} from '@tanstack/react-query';
import {ReactQueryDevtools} from '@tanstack/react-query-devtools';
import {ConfigProvider} from 'antd';
import 'antd/dist/reset.css';
import ruRU from 'antd/es/locale/ru_RU';
import axios from 'axios';
import dayjs from 'dayjs';
import 'dayjs/locale/ru';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import duration from 'dayjs/plugin/duration';
import isBetween from 'dayjs/plugin/isBetween';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import localizedFormat from 'dayjs/plugin/localizedFormat';
import minMax from 'dayjs/plugin/minMax';
import relativeTime from 'dayjs/plugin/relativeTime';
import timezone from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';
import {StrictMode} from 'react';
import ReactDOM from 'react-dom/client';
import {RecoilRoot} from 'recoil';

import './global.css';

dayjs.extend(utc);
dayjs.extend(relativeTime);
dayjs.extend(localizedFormat);
dayjs.extend(isBetween);
dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);
dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(duration);
dayjs.extend(customParseFormat);
dayjs.extend(minMax);

dayjs.locale('ru');

axios.defaults.paramsSerializer = {
    indexes: null,
};

// @ts-expect-error It's okay type
ReactDOM.createRoot(document.getElementById('root')).render(
    <StrictMode>
        <RecoilRoot>
            <QueryClientProvider client={queryClient}>
                <ConfigProvider
                    direction="ltr"
                    form={{colon: false, validateMessages: validateMessagesWithLabels}}
                    locale={ruRU}
                    theme={theme}
                >
                    <StyleProvider hashPriority="high">
                        <AxiosInterceptorAccess />
                        <AxiosInterceptorMessage />
                        <RouterProviderWrapper />
                    </StyleProvider>
                </ConfigProvider>
                <ReactQueryDevtools />
            </QueryClientProvider>
        </RecoilRoot>
    </StrictMode>,
);
