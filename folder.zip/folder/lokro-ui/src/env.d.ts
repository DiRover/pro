interface ImportMetaEnv {
    readonly VITE_GIT_COMMIT?: string;
    readonly VITE_GIT_BRANCH?: string;
    readonly VITE_AUTO_BACK_MS?: string;
}

interface ImportMeta {
    readonly env: ImportMetaEnv;
}
