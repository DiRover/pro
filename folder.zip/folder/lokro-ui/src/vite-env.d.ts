/// <reference types="vite/client" />

declare const __BUILD_DATE__: string;
declare const __VERSION__: string;
