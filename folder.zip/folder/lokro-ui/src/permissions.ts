import {RoleDtoName} from '@generated/model';

function unique(...roles: RoleDtoName[] | RoleDtoName[][]) {
    return Array.from(new Set(roles.flat(1)));
}

// ---

export const HIERARCHY_VIEW = [RoleDtoName.ADMIN, RoleDtoName.MANAGER, RoleDtoName.OBSERVER];

// ---

export const CO_EDIT = [RoleDtoName.ADMIN];
export const CO_EDIT_PLAN = [RoleDtoName.ADMIN];
export const CO_EDIT_SCENE = [RoleDtoName.ADMIN];
export const CO_EDIT_MARK = [RoleDtoName.ADMIN];

export const CP_EDIT = [RoleDtoName.ADMIN];
export const CP_VIEW_PAGE = unique(...CP_EDIT, RoleDtoName.MANAGER, RoleDtoName.SHIFTMASTER);

export const HP_EDIT = [RoleDtoName.SHIFTMASTER, RoleDtoName.PERFORMER];
export const HP_VIEW_PAGE = [RoleDtoName.MANAGER, RoleDtoName.SHIFTMASTER];
export const HP_VIEW = unique(...HP_EDIT, ...HP_VIEW_PAGE);

export const HP_VIEW_LAYER = unique(...HP_VIEW, RoleDtoName.OBSERVER);

export const TS_EDIT = [RoleDtoName.ADMIN];
export const TS_VIEW = unique(...TS_EDIT, RoleDtoName.MANAGER, RoleDtoName.SHIFTMASTER);

export const DE_EDIT = [RoleDtoName.ADMIN];
export const DE_VIEW = DE_EDIT;

export const REGISTRY_SECTION = unique(...CP_VIEW_PAGE, ...HP_VIEW, ...TS_VIEW, ...DE_VIEW);

// ---

export const REGULATION_SECTION = [RoleDtoName.MANAGER];

// ---

export const TASK_CREATE_WITH_DEPARTMENT = [RoleDtoName.MANAGER];
export const TASK_CREATE = unique(...TASK_CREATE_WITH_DEPARTMENT, RoleDtoName.SHIFTMASTER);
export const TASK_VIEW_HISTORY = [RoleDtoName.MANAGER];
export const TASK_VIEW = unique(...TASK_CREATE, ...TASK_VIEW_HISTORY, RoleDtoName.PERFORMER);

export const TASK_SECTION = TASK_VIEW;

// ---

export const REPORT_SECTION = [RoleDtoName.MANAGER];

export const SETTINGS_SECTION = [RoleDtoName.ADMIN];

export const REFERENCE_SECTION = [RoleDtoName.ADMIN];

export const AUDIT_SECTION = [RoleDtoName.ADMIN];
