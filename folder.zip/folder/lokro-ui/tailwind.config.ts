import type {Config} from 'tailwindcss';

export default {
    content: ['./index.html', './src/**/*.{ts,tsx}'],
    plugins: [],
    theme: {
        extend: {
            colors: {
                accent: 'rgb(var(--color-accent) / <alpha-value>)',
                primary: 'rgb(var(--color-primary) / <alpha-value>)',
            },
            spacing: {
                header: 'var(--height-header)',
                'safe-screen': 'calc(100vh - var(--height-header))',
            },
        },
    },
} satisfies Config;
