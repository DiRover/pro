import react from '@vitejs/plugin-react-swc';
import path from 'path';
import {defineConfig} from 'vite';

const buildDate = Date.now();
const version = process.env.npm_package_version;

export default defineConfig({
    define: {
        __BUILD_DATE__: JSON.stringify(buildDate),
        __VERSION__: JSON.stringify(version),
    },
    css: {
        preprocessorMaxWorkers: true,
    },
    plugins: [react()],
    resolve: {
        alias: {
            '@': path.resolve(__dirname, './src'),
            '@generated': path.resolve(__dirname, './generated'),
        },
    },
    server: {
        port: 3000,
        proxy: {
            '/webapp': {
                changeOrigin: true,
                // rewrite: path => path.replace(/^\/webapp/, ''),
                secure: true,
                target: 'https://lokro-dev.element-soft.com',
            },
        },
    },
});
