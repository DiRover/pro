import {defineConfig} from 'orval';

export default defineConfig({
    api: {
        hooks: {
            afterAllFilesWrite: 'prettier --write',
        },
        input: {
            override: {
                transformer: ({paths, ...rest}) => {
                    return {
                        ...rest,
                        paths: Object.entries(paths).reduce((acc, [url, val]) => {
                            return {
                                ...acc,
                                ['/webapp' + url]: val,
                            };
                        }, {}),
                    };
                },
            },
            target: 'https://lokro-dev.element-soft.com/webapp/v3/api-docs',
        },
        output: {
            override: {
                useDeprecatedOperations: false,

                query: {
                    useQuery: true,
                    useSuspenseQuery: true,
                },

                operations: {
                    // techno-system list
                    getAll: {
                        query: {
                            useInfinite: true,
                            useInfiniteQueryParam: 'page',
                            useQuery: true,
                            signal: true,
                            shouldExportQueryKey: true,
                        },
                    },
                    getEquipmentsById: {
                        query: {
                            useInfinite: true,
                            useInfiniteQueryParam: 'page',
                            useQuery: true,
                            signal: true,
                            shouldExportQueryKey: true,
                        },
                    },
                    getAllControlObject: {
                        query: {
                            useInfinite: true,
                            useInfiniteQueryParam: 'page',
                            useQuery: true,
                            signal: true,
                            shouldExportQueryKey: true,
                        },
                    },
                    getAllReportsByType: {
                        query: {
                            useInfinite: true,
                            useInfiniteQueryParam: 'page',
                            useQuery: true,
                            signal: true,
                            shouldExportQueryKey: true,
                        },
                    },
                },
            },
            clean: true,
            client: 'react-query',
            headers: true,
            mock: false,
            mode: 'tags',
            schemas: 'generated/model',
            target: 'generated/endpoints',
        },
    },
});
