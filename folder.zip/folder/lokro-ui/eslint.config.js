import reactRefreshPlugin from 'eslint-plugin-react-refresh';
import perfectionistPlugin from 'eslint-plugin-perfectionist';
import globals from 'globals';
import jsEslint from '@eslint/js';
import tsEslint from 'typescript-eslint';
import reactHooksPlugin from 'eslint-plugin-react-hooks';
import reactPlugin from 'eslint-plugin-react';
import prettierPlugin from 'eslint-plugin-prettier';
import tailwindPlugin from 'eslint-plugin-tailwindcss';
import queryPlugin from '@tanstack/eslint-plugin-query';
import prettierConfig from 'eslint-config-prettier';

export default tsEslint.config(
    {
        files: ['**/*.ts', '**/*.tsx'],
    },

    {
        extends: [
            jsEslint.configs.recommended,
            ...tsEslint.configs.strictTypeChecked,
            ...tsEslint.configs.stylisticTypeChecked,
            reactPlugin.configs.flat.recommended,
            reactPlugin.configs.flat['jsx-runtime'],
            ...tailwindPlugin.configs['flat/recommended'],
            ...queryPlugin.configs['flat/recommended'],
            prettierConfig,
        ],

        languageOptions: {
            globals: globals.browser,
            ecmaVersion: 'latest',
            parserOptions: {
                project: ['./tsconfig.app.json', './tsconfig.node.json'],
            },
        },

        plugins: {
            'react-refresh': reactRefreshPlugin,
            'react-hooks': reactHooksPlugin,
            perfectionist: perfectionistPlugin,
            prettier: prettierPlugin,
            tailwindcss: tailwindPlugin,
        },

        settings: {
            react: {
                version: 'detect',
            },
            tailwindcss: {
                config: 'tailwind.config.ts',
                whitelist: ['active', 'pending', 'full-size-container', 'group-section', 'single-page', 'tabs'],
            },
        },

        rules: {
            ...prettierPlugin.configs.recommended.rules,
            'perfectionist/sort-imports': [
                2,
                {
                    type: 'natural',
                    order: 'asc',
                },
            ],

            'react-refresh/only-export-components': [
                2,
                {
                    allowConstantExport: true,
                },
            ],

            '@typescript-eslint/consistent-type-imports': [2],
            '@typescript-eslint/unbound-method': [0],
            '@typescript-eslint/no-misused-promises': [
                1,
                {
                    checksVoidReturn: false,
                },
            ],
            '@typescript-eslint/no-unused-vars': [2, {ignoreRestSiblings: true}],
            '@typescript-eslint/restrict-template-expressions': [0],

            '@tanstack/query/exhaustive-deps': [2],
            '@tanstack/query/stable-query-client': [2],

            'no-restricted-imports': [
                2,
                {
                    paths: [
                        {
                            name: 'react',
                            importNames: ['default'],
                            message: "Dont use 'import React from 'react''.",
                        },
                        {
                            name: 'react-router',
                            message: 'Please use import from react-router-dom instead.',
                        },
                    ],
                },
            ],

            'react/react-in-jsx-scope': [0],
            'react/display-name': [0],
            'react/prop-types': [0],
            'react-hooks/rules-of-hooks': [2],
            'react-hooks/exhaustive-deps': [2],
            'no-console': [2],

            'prefer-const': [
                2,
                {
                    destructuring: 'all',
                },
            ],
        },
    },
    {
        ignores: [
            'node_modules/',
            'generated/',
            'dist/',
            'vite.config.ts',
            'orval.config.ts',
            'tailwind.config.ts',
            'postcss.config.js',
            'eslint.config.js',
        ],
    },
);
