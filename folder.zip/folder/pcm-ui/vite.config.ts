import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

const version = process.env.npm_package_version;
const buildDate = Date.now();

export default defineConfig({
    define: {
        __BUILD_DATE__: JSON.stringify(buildDate),
        __VERSION__: JSON.stringify(version),
    },
    plugins: [react()],
    resolve: {
        alias: {
            '@': path.resolve(__dirname, './src'),
            '@generated': path.resolve(__dirname, './generated'),
        },
    },
    server: {
        port: 3000,
        proxy: {
            '/webapp': {
                changeOrigin: true,
                secure: true,
                target: 'https://pcm-dev.element-soft.com',
            },
        },
    },
});
