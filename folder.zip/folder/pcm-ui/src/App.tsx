/**
 * Created by VIATKIN A.A. on 09.11.2023
 */

import Header from '@/components/layout/Header.tsx';
import {useTokenRotation} from '@/hooks/useTokenRotation.ts';
import Meta from '@/routes/Meta.tsx';
import RouterLoader from '@/routes/RouterLoader.tsx';
import {Spin} from 'antd';
import {memo} from 'react';
import {Outlet, useNavigation} from 'react-router-dom';

export const Component = memo(() => {
    const {expired} = useTokenRotation();
    const {state} = useNavigation();

    return (
        <>
            <Header />

            {expired ? <Spin tip="Обновляем доступы">&nbsp;</Spin> : <Outlet />}

            <Meta />

            {state === 'loading' && <RouterLoader />}
        </>
    );
});
