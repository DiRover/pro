import AxiosInterceptorAccess from '@/components/utils/AxiosInterceptorAccess.tsx';
import {queryClient} from '@/libs/queryClient.ts';
import {theme} from '@/libs/theme.ts';
import {validateMessages} from '@/libs/validateMessages.ts';
import RouterProviderWrapper from '@/routes/RouterProviderWrapper.tsx';
import {StyleProvider} from '@ant-design/cssinjs';
import {QueryClientProvider} from '@tanstack/react-query';
import {ReactQueryDevtools} from '@tanstack/react-query-devtools';
import {ConfigProvider} from 'antd';
import ru_RU from 'antd/locale/ru_RU';
import * as dayjs from 'dayjs';
import 'dayjs/locale/ru';
import duration from 'dayjs/plugin/duration';
import localizedFormat from 'dayjs/plugin/localizedFormat';
import objectSupport from 'dayjs/plugin/objectSupport';
import relativeTime from 'dayjs/plugin/relativeTime';
import timezone from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';
import {StrictMode, Suspense, lazy} from 'react';
import {createRoot} from 'react-dom/client';
import {RecoilRoot} from 'recoil';

import './global.css';

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(localizedFormat);
dayjs.extend(relativeTime);
dayjs.extend(duration);
dayjs.extend(objectSupport);
dayjs.locale('ru');

const AxiosInterceptorMessage = lazy(() => import('@/components/presentation/AxiosInterceptorMessage.tsx'));

createRoot(document.getElementById('app')!).render(
    <StrictMode>
        <RecoilRoot>
            <QueryClientProvider client={queryClient}>
                <ConfigProvider direction="ltr" form={{colon: false, validateMessages}} locale={ru_RU} theme={theme}>
                    <StyleProvider hashPriority="high">
                        <AxiosInterceptorAccess />

                        <Suspense fallback={null}>
                            <AxiosInterceptorMessage />
                        </Suspense>

                        <RouterProviderWrapper />
                    </StyleProvider>

                    <ReactQueryDevtools initialIsOpen={false} />
                </ConfigProvider>
            </QueryClientProvider>
        </RecoilRoot>
    </StrictMode>,
);
