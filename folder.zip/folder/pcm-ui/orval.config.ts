import {defineConfig} from 'orval';

export default defineConfig({
    webapp: {
        hooks: {
            afterAllFilesWrite: 'prettier --write',
        },
        input: {
            override: {
                transformer: ({paths, ...rest}) => {
                    return {
                        ...rest,
                        paths: Object.entries(paths).reduce((acc, [url, val]) => {
                            return {
                                ...acc,
                                ['/webapp' + url]: val,
                            };
                        }, {}),
                    };
                },
            },
            target: 'http://pcm-dev.element-soft.com:8090/v3/api-docs',
        },
        output: {
            clean: true,
            client: 'react-query',
            headers: true,
            mock: false,
            mode: 'tags',
            schemas: 'generated/model',
            target: 'generated/endpoints',
        },
    },
});
