module.exports = {
    root: true,
    env: {browser: true, es2023: true},
    extends: [
        'prettier',
        'plugin:prettier/recommended',
        'plugin:tailwindcss/recommended',
        'eslint:recommended',
        'plugin:@typescript-eslint/recommended',
        'plugin:react/recommended',
        'plugin:react-hooks/recommended',
        'plugin:perfectionist/recommended-natural',
        'plugin:@tanstack/eslint-plugin-query/recommended',
    ],
    ignorePatterns: ['dist', '.eslintrc.cjs'],
    parser: '@typescript-eslint/parser',
    parserOptions: {
        tsconfigRootDir: __dirname,
        project: ['./tsconfig.json'],
        sourceType: 'module',
    },
    plugins: ['react', 'react-hooks', 'react-refresh', 'tailwindcss', 'perfectionist', '@tanstack/query'],
    rules: {
        'react-refresh/only-export-components': [1, {allowConstantExport: true}],

        '@typescript-eslint/ban-ts-comment': [2],
        '@typescript-eslint/consistent-type-imports': [2],
        '@typescript-eslint/no-namespace': [2],
        '@typescript-eslint/no-unused-vars': [2, {argsIgnorePattern: '^_', ignoreRestSiblings: true}],
        '@typescript-eslint/no-explicit-any': [2],
        '@typescript-eslint/no-unsafe-call': [2],
        '@typescript-eslint/no-unsafe-member-access': [2],
        '@typescript-eslint/no-floating-promises': [2],
        '@typescript-eslint/no-misused-promises': [
            2,
            {
                checksVoidReturn: false,
            },
        ],
        '@typescript-eslint/require-await': [2],
        '@typescript-eslint/array-type': [
            2,
            {
                default: 'generic',
            },
        ],

        'react-hooks/rules-of-hooks': [2],
        'react-hooks/exhaustive-deps': [2],

        'no-restricted-imports': [
            'error',
            {
                paths: [
                    {
                        name: 'react',
                        importNames: ['default'],
                        message: "Dont use 'import React from 'react''.",
                    },
                    {
                        name: 'react-router',
                        message: 'Please use import from react-router-dom instead.',
                    },
                ],
            },
        ],

        'react/jsx-boolean-value': [2],
        'react/jsx-curly-brace-presence': [2],
        'react/self-closing-comp': [2],
        'react/react-in-jsx-scope': [0],
        'react/prop-types': [0],
        'react/display-name': [0],

        'no-console': [2],

        '@tanstack/query/exhaustive-deps': [2],
        '@tanstack/query/no-rest-destructuring': [1],
        '@tanstack/query/stable-query-client': [2],
    },
    settings: {
        react: {
            version: 'detect',
        },
        tailwindcss: {
            config: 'tailwind.config.mjs',
        },
    },
};
