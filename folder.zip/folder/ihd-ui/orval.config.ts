import {defineConfig} from 'orval';

type AllConfigs = Extract<Parameters<typeof defineConfig>[number], Record<string, unknown>>;
type Config = AllConfigs[string];
type ConfigAsObject = Exclude<Config, Promise<unknown> | Function>;
type Output = ConfigAsObject['output'];
type OutputOptions = Exclude<Output, string | undefined>;
type Operations = Required<OutputOptions>['override']['operations'];

function generateConfig(service: string, target: string, operations?: Operations): Config {
    return {
        hooks: {
            afterAllFilesWrite: 'prettier --write',
        },
        input: {
            override: {
                transformer: ({paths, ...rest}) => {
                    return {
                        ...rest,
                        paths: Object.entries(paths).reduce((acc, [url, val]) => {
                            return {
                                ...acc,
                                [`/api/${service}${url}`]: val,
                            };
                        }, {}),
                    };
                },
            },
            target,
        },
        output: {
            clean: true,
            client: 'react-query',
            headers: true,
            mock: false,
            mode: 'tags',
            schemas: `generated/${service}/model`,
            target: `generated/${service}/endpoints`,
            override: {
                useNativeEnums: true,
                useDeprecatedOperations: true,
                operations,
                query: {
                    useQuery: true,
                    useSuspenseQuery: true
               },
            },
        },
    };
}

export default defineConfig({
    auth: generateConfig('auth', 'https://ihd-dev.element-soft.com/api/auth/openapi.json', {
        read_audit_records_audit_records_get: {
            query: {
                useInfinite: true,
                useInfiniteQueryParam: 'page_number',
                useQuery: true,
                signal: true,
            },
        },
    }),
    import: generateConfig('import', 'https://ihd-dev.element-soft.com/api/import/openapi.json'),
    accounting: generateConfig('accounting', 'https://ihd-dev.element-soft.com/api/accounting/openapi.json', {
        directories_global_search_directories_global_search_get: {
            query: {
                useInfinite: true,
                useInfiniteQueryParam: 'page_number',
                useQuery: true,
                signal: true,
            },
        },
    }),
    reporting: generateConfig('reporting', 'https://ihd-dev.element-soft.com/api/reporting/openapi.json'),
});
