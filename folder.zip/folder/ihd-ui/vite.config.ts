import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react-swc';
import {resolve} from 'path';
import svgr from 'vite-plugin-svgr';

const buildDate = Date.now();
const version = process.env.npm_package_version;

// https://vitejs.dev/config/
export default defineConfig({
    define: {
        __BUILD_DATE__: JSON.stringify(buildDate),
        __VERSION__: JSON.stringify(version),
    },
    css: {
        preprocessorMaxWorkers: true,
    },
    server: {
        port: 3000,
        host: true,
        proxy: {
            '/api': {
                changeOrigin: true,
                // rewrite: path => path.replace(/^\/api/, ''),
                secure: true,
                target: 'https://ihd-dev.element-soft.com',
            },
        },
    },
    resolve: {
        alias: {
            '@': resolve(__dirname, './src'),
            '@generated': resolve(__dirname, './generated'),
        },
    },
    plugins: [
        react({
            devTarget: 'es2022',
        }),
        svgr({
            svgrOptions: {
                memo: true,
                // jsxRuntime: 'automatic',
                typescript: false,
                index: false,
                plugins: ['@svgr/plugin-svgo', '@svgr/plugin-jsx'],
                svgoConfig: {
                    plugins: [
                        {
                            name: 'preset-default',
                            params: {
                                overrides: {
                                    removeViewBox: false,
                                },
                            },
                        },
                        {
                            name: 'removeAttrs',
                            params: {
                                attrs: '(fill|stroke|fill-opacity)',
                            },
                        },
                        {
                            name: 'removeDimensions',
                        },
                        {
                            name: 'addAttributesToSVGElement',
                            params: {
                                attributes: [
                                    {
                                        width: '1em',
                                    },
                                    {
                                        height: '1em',
                                    },
                                    {
                                        fill: 'transparent',
                                        stroke: 'currentColor',
                                    },
                                ],
                            },
                        },
                    ],
                },
            },
        }),
    ],
});
