import {tokenSelector} from '@/atoms/token.ts';
import useHere from '@/hooks/useHere.ts';
import {useRefreshRefreshPost} from '@generated/auth/endpoints/auth.ts';
import {useEffect} from 'react';
import {useRecoilState} from 'recoil';

export function useTokenRefresh() {
    useHere();

    const [token, setToken] = useRecoilState(tokenSelector);

    const isExpired = token ? token.access_token_expires * 1000 <= Date.now() : false;

    const {isPending, mutate} = useRefreshRefreshPost({
        mutation: {
            onSuccess({data}) {
                setToken(data);
            },
        },
    });

    useEffect(() => {
        if (!token || isPending) return;

        const {access_token_expires, refresh_token} = token;

        const delta = 3000;
        const ms = Math.max(access_token_expires * 1000 - Date.now() - delta, 0);

        const t = setTimeout(() => {
            mutate({
                data: {
                    refresh_token,
                },
            });
        }, ms);

        return () => {
            clearTimeout(t);
        };
    }, [isPending, mutate, token, isExpired]);

    return {isExpired} as const;
}
