import type {BodyLoginLoginPost} from '@generated/auth/model';

import {tokenSelector} from '@/atoms/token.ts';
import {useLoginByEdsLoginByEdsPost, useLoginLoginPost, useLogoutLogoutPost} from '@generated/auth/endpoints/auth.ts';
import {useAddEdsUsersMyAddEdsPatch, useRemoveEdsUsersMyRemoveEdsPatch} from '@generated/auth/endpoints/users.ts';
import {useIsMutating} from '@tanstack/react-query';
import {useCallback} from 'react';
import {useRecoilState} from 'recoil';

export default function useToken() {
    const [token, setToken] = useRecoilState(tokenSelector);

    const loading = useIsMutating({exact: false, mutationKey: ['auth']}) > 0;

    const {mutate} = useLoginLoginPost({
        mutation: {
            mutationKey: ['auth', 'login'],
            onSuccess({data}) {
                setToken(data);
            },
        },
    });

    const login = useCallback(
        (data: BodyLoginLoginPost) => {
            mutate({
                data,
            });
        },
        [mutate],
    );

    const {mutate: exit} = useLogoutLogoutPost({
        mutation: {
            mutationKey: ['auth', 'logout'],
            onSettled() {
                sessionStorage.clear();
                setToken(null);
            },
        },
    });

    const logout = useCallback(() => {
        exit();
    }, [exit]);

    const {mutate: addEds} = useAddEdsUsersMyAddEdsPatch({
        mutation: {
            mutationKey: ['auth', 'eds-add'],
            onSuccess() {
                setToken(prev =>
                    prev
                        ? {
                              ...prev,
                              has_eds: true,
                          }
                        : null,
                );
            },
        },
    });

    const setCert = useCallback(
        (thumbprint: string) => {
            addEds({
                data: {
                    eds: thumbprint,
                },
            });
        },
        [addEds],
    );

    const {mutate: removeEds} = useRemoveEdsUsersMyRemoveEdsPatch({
        mutation: {
            mutationKey: ['auth', 'eds-remove'],
            onSuccess() {
                setToken(prev =>
                    prev
                        ? {
                              ...prev,
                              has_eds: false,
                          }
                        : null,
                );
            },
        },
    });

    const removeCert = useCallback(() => {
        removeEds();
    }, [removeEds]);

    const {mutate: mutateEDS} = useLoginByEdsLoginByEdsPost({
        mutation: {
            mutationKey: ['auth', 'login-eds'],
            onSuccess({data}) {
                setToken(data);
            },
        },
    });

    const loginEDS = useCallback(
        (thumbprint: string) => {
            mutateEDS({
                data: {
                    eds: thumbprint,
                },
            });
        },
        [mutateEDS],
    );

    return {loading, login, loginEDS, logout, removeCert, setCert, token} as const;
}
