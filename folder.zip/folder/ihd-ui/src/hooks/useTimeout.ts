import {useCallback, useEffect, useRef} from 'react';

type Fn = () => void;

export default function useTimeout(callbackFn: Fn, ms = 300) {
    const t = useRef(-1);
    const callbackRef = useRef(callbackFn);

    useEffect(() => {
        callbackRef.current = callbackFn;
    }, [callbackFn]);

    const cancel = useCallback(() => {
        window.clearTimeout(t.current);
    }, []);

    const start = useCallback(() => {
        cancel();
        t.current = window.setTimeout(callbackRef.current, ms);
    }, [cancel, ms]);

    useEffect(() => {
        return () => {
            cancel();
        };
    }, [cancel]);

    return {cancel, start} as const;
}
