import {edsInitAtom, listCertificatesSelector} from '@/atoms/eds.ts';
import {useRecoilRefresher_UNSTABLE, useRecoilValueLoadable} from 'recoil';

export default function useEDS() {
    const init = useRecoilValueLoadable(edsInitAtom);
    const listCertificates = useRecoilValueLoadable(listCertificatesSelector);
    const refresh = useRecoilRefresher_UNSTABLE(listCertificatesSelector);
    return {init, listCertificates, refresh} as const;
}
