import {nanoid} from 'nanoid';
import {useMemo, useRef} from 'react';
import isEqual from 'react-fast-compare';

type useDeepMemoResult<T> = [T, string];

function useDeepMemo<T>(obj: T): useDeepMemoResult<T> {
    const prev = useRef<useDeepMemoResult<T>>([obj, nanoid(6)]);

    return useMemo(() => {
        const eq = isEqual(obj, prev.current[0]);
        if (!eq) prev.current = [obj, nanoid(6)];
        return prev.current;
    }, [obj]);
}

export default useDeepMemo;
