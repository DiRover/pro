import {useEffect, useState} from 'react';

function check() {
    return document.visibilityState === 'visible';
}

export default function useHere() {
    const [here, setHere] = useState(() => check());

    useEffect(() => {
        const handler = () => {
            setHere(check());
        };

        document.addEventListener('visibilitychange', handler);

        handler();

        return () => {
            document.removeEventListener('visibilitychange', handler);
        };
    }, []);

    return here;
}
