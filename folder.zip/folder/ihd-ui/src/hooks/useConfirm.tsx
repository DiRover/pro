import type {RuleRender} from 'antd/es/form';
import type {ModalFunc} from 'antd/es/modal/confirm';

import {Alert, Form, Input, Modal, Typography} from 'antd';
import {useCallback, useRef} from 'react';

const {useModal} = Modal;
const {Item} = Form;

export function useConfirm(word: string, onSuccess: () => void) {
    const [api, ctx] = useModal();
    const modal = useRef<ReturnType<ModalFunc>>();

    const onFinish = useCallback(() => {
        modal.current?.destroy();
        onSuccess();
    }, [onSuccess]);

    const checkRule: RuleRender = useCallback(
        () => ({
            validator(_, value?: string) {
                return new Promise((resolve, reject) => {
                    if (!value || value === word) {
                        resolve('');
                    } else {
                        reject(new Error('Проверочное слово не совпадает'));
                    }
                });
            },
        }),
        [word],
    );

    const confirm = useCallback(() => {
        modal.current = api.confirm({
            content: (
                <Form layout="vertical" name="ConfirmForm" onFinish={onFinish}>
                    <Alert
                        description={
                            <>
                                Для подтверждения введите в поле ниже слово&nbsp;
                                <Typography.Text keyboard>{word}</Typography.Text>
                            </>
                        }
                        message="Подтверждение"
                        type="warning"
                    />
                    <Item label="Проверочное слово" name="word" rules={[{required: true}, checkRule]}>
                        <Input
                            autoComplete="off"
                            onPaste={e => {
                                e.preventDefault();
                            }}
                            placeholder={word}
                        />
                    </Item>
                </Form>
            ),
            okButtonProps: {
                danger: true,
                form: 'ConfirmForm',
                htmlType: 'submit',
            },
            okText: 'Подтвердить',
            onOk() {
                return Promise.reject(new Error('Prevent'));
            },
            title: 'Внимание',
        });
    }, [api, checkRule, onFinish, word]);

    return [confirm, ctx] as const;
}
