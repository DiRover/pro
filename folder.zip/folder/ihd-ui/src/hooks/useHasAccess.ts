/**
 * Created by VIATKIN A.A. on 23.12.2019
 */

import type {PrivilegesEnum} from '@generated/auth/model';

import useToken from '@/hooks/useToken.ts';
import {hasAccess} from '@/libs/utils.ts';
import {useMemo} from 'react';

function useHasAccess(...permissions: PrivilegesEnum[]) {
    const {token} = useToken();
    const privileges = token?.user.group?.privileges.map(({value}) => value);
    return useMemo(() => {
        return hasAccess(privileges, permissions);
    }, [privileges, permissions]);
}

export default useHasAccess;
