import type {CancelTokenSource} from 'axios';

import axios from 'axios';
import {useCallback, useEffect, useRef, useState} from 'react';

function useFileLoader<T extends Record<string, unknown> = Record<string, unknown>>(
    fileName: string,
    url: string,
    params?: T,
) {
    const canceler = useRef<CancelTokenSource | null>(null);
    const [loading, setLoading] = useState(false);
    const [progress, setProgress] = useState(0);

    const download = useCallback(
        async (downloadParams?: T): Promise<void> => {
            try {
                canceler.current = axios.CancelToken.source();
                setLoading(true);
                setProgress(0);

                const {data: blob, headers} = await axios.get<Blob>(url, {
                    cancelToken: canceler.current.token,
                    onDownloadProgress({loaded, total}) {
                        if (total) {
                            const completed = Math.round((loaded * 100) / total);
                            setProgress(completed);
                        }
                    },
                    params: {...params, ...downloadParams},
                    responseType: 'blob',
                });

                const contentDisposition =
                    'get' in headers && typeof headers.get === 'function' ? headers.get('content-disposition') : '';

                let currentFileName = '';

                if (typeof contentDisposition === 'string' && contentDisposition) {
                    currentFileName = contentDisposition.split('filename=').at(-1) ?? '';
                    if (currentFileName) currentFileName = decodeURIComponent(currentFileName.slice(1, -1));
                }

                if (!currentFileName) currentFileName = fileName;

                const urlCreator = window.URL;
                const urlFromBlob = urlCreator.createObjectURL(blob);

                const a = document.createElement('a');

                document.body.appendChild(a);
                a.style.display = 'none';
                a.href = urlFromBlob;
                a.download = currentFileName;
                a.click();
                urlCreator.revokeObjectURL(urlFromBlob);
                a.remove();

                setLoading(false);
                setProgress(100);
            } catch (e) {
                if (!axios.isCancel(e)) {
                    setLoading(false);
                    setProgress(0);
                }
            }
        },
        [fileName, url, params],
    );

    useEffect(() => {
        return () => {
            canceler.current?.cancel();
        };
    }, []);

    return {
        download,
        loading,
        progress,
    };
}

export default useFileLoader;
