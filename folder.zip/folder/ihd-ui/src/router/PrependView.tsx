/**
 * Created by VIATKIN A.A. on 16.02.2024
 */

import {isMatchesHandle} from '@/router/types.ts';
import {Fragment, memo} from 'react';
import {useMatches} from 'react-router-dom';

const PrependView = memo(() => {
    const matches = useMatches();
    return matches
        .filter(isMatchesHandle)
        .map(({handle: {prepend: Prepend}, id}) => <Fragment key={id}>{Prepend && <Prepend />}</Fragment>);
});

export default PrependView;
