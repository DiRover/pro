/**
 * Created by VIATKIN A.A. on 04.04.2023
 */

import {isMatchesHandle} from '@/router/types.ts';
import {memo, useEffect} from 'react';
import {useMatches} from 'react-router-dom';

const Meta = memo(() => {
    const matches = useMatches();

    useEffect(() => {
        document.title = Array.from(
            new Set(
                matches
                    .filter(isMatchesHandle)
                    .map(({handle: {title}}) => title)
                    .reverse(),
            ),
        ).join(' | ');
    }, [matches]);

    return null;
});

export default Meta;
