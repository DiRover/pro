import type {PrivilegesEnum} from '@generated/auth/model';

import {hasAccess} from '@/libs/utils.ts';
import {createBrowserRouter} from 'react-router-dom';

import type {reason} from './PageRedirect.tsx';
import type {RouteObjectWithHandleSlim} from './types.ts';
import type {IndexRouteObjectWithHandle, RouteObjectWithHandle} from './types.ts';

import PageRedirect from './PageRedirect.tsx';
import RouterError from './RouterError.tsx';
import routes from './routes.tsx';

function isIndexRoute(route: RouteObjectWithHandle): route is IndexRouteObjectWithHandle {
    return !!route.index;
}

function getSlimRoutes(all?: RouteObjectWithHandle[]): RouteObjectWithHandleSlim[] | null {
    if (!all) return null;

    return all.map(({handle, index, path}) => ({
        handle,
        index,
        path,
    }));
}

function wrap(
    all: RouteObjectWithHandle[],
    isAuth: boolean,
    permissions?: PrivilegesEnum[],
    parentRestricted = false,
): RouteObjectWithHandle[] {
    return all.map(route => {
        const {handle, loader} = route;

        let restrictedReason: null | reason = null;

        if (handle) {
            if (isAuth) {
                if (handle.free && handle.restrictedWithAuth) {
                    restrictedReason = 'restricted-with-auth';
                } else if (parentRestricted || !hasAccess(permissions, handle.permissions)) {
                    restrictedReason = 'not-enough-permission';
                }
            } else {
                if (!handle.free) restrictedReason = 'no-auth';
            }
        }

        const isIndex = isIndexRoute(route);
        const wrapped = isIndex ? undefined : wrap(route.children ?? [], isAuth, permissions, !!restrictedReason);

        return {
            ...route,
            children: wrapped,
            element: restrictedReason ? <PageRedirect reason={restrictedReason} /> : route.element,
            errorElement: route.errorElement ?? <RouterError />,
            lazy: restrictedReason ? undefined : route.lazy,
            loader: restrictedReason
                ? undefined
                : typeof loader === 'function'
                  ? async (...args) => {
                        const res = await Promise.all([
                            Promise.resolve(getSlimRoutes([route])),
                            Promise.resolve(getSlimRoutes(wrapped)),
                            loader(...args),
                        ]);

                        const last = res.at(-1);

                        return last instanceof Response ? last : res;
                    }
                  : () =>
                        Promise.all([Promise.resolve(getSlimRoutes([route])), Promise.resolve(getSlimRoutes(wrapped))]),
        };
    });
}

export default function getRouter(isAuth: boolean, permissions?: PrivilegesEnum[]) {
    return createBrowserRouter(wrap(routes, isAuth, permissions));
}
