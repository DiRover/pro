/**
 * Created by VIATKIN A.A. on 17.07.2023
 */

import BodyPortal from '@/components/common/BodyPortal.tsx';
import {memo} from 'react';

const RouterLoader = memo(() => {
    return (
        <BodyPortal>
            <div className="pointer-events-none fixed inset-0 grid place-content-center">
                <span>Загружаем</span>
            </div>
        </BodyPortal>
    );
});

export default RouterLoader;
