/**
 * Created by VIATKIN A.A. on 14.02.2024
 */

import AppendView from '@/router/AppendView.tsx';
import PrependView from '@/router/PrependView.tsx';
import {useRouteChildren} from '@/router/useRouteChildren.ts';
import clsx from 'clsx';
import {Suspense, memo} from 'react';
import {NavLink, Outlet} from 'react-router-dom';

export const Component = memo(() => {
    const {current, routes} = useRouteChildren();

    return (
        <>
            <aside className="sticky top-0 h-svh w-72 shrink-0 overflow-y-auto border-r bg-secondary">
                <div className="flex flex-col gap-4 border-b p-4">
                    <h1 className="text-xl">{current?.handle?.title ?? '?'}</h1>

                    <Suspense fallback={null}>
                        <PrependView />
                    </Suspense>
                </div>

                <div className="flex flex-col border-b p-4 empty:hidden">
                    {routes.map(({handle, path}, idx) => (
                        <NavLink
                            className={({isActive, isPending, isTransitioning}) =>
                                clsx(
                                    'flex items-center gap-x-2 rounded px-3 py-2',
                                    isActive ? 'bg-primary/10 text-primary' : 'hover:bg-neutral-100',
                                    (isPending || isTransitioning) && 'radial-gradient',
                                )
                            }
                            end={!path}
                            key={idx}
                            to={path ?? '.'}
                        >
                            <span className="text-lg opacity-40 empty:hidden">{handle?.icon && <handle.icon />}</span>

                            <span className="text-sm">{handle?.title}</span>
                        </NavLink>
                    ))}
                </div>

                <Suspense fallback={null}>
                    <AppendView />
                </Suspense>
            </aside>

            <Outlet />
        </>
    );
});
