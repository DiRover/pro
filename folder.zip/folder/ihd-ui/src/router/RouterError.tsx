import type {APIError} from '@/libs/utils.ts';

import Sad from '@/assets/icons/sad.svg?react';
import {getTextError} from '@/libs/utils.ts';
import {isAxiosError} from 'axios';
import {memo, useMemo} from 'react';
import {isRouteErrorResponse, Link, useRouteError} from 'react-router-dom';

const RouterError = memo(() => {
    const routeError = useRouteError();

    const {
        isChunkError = false,
        subTitle,
        title,
    } = useMemo(() => {
        if (isAxiosError<APIError>(routeError) && routeError.response) {
            return {
                subTitle: getTextError(routeError.response.data),
                title: routeError.response.status,
            };
        }

        if (routeError instanceof Error) {
            return {
                isChunkError:
                    routeError.name === 'ChunkLoadError' ||
                    (routeError.name === 'TypeError' &&
                        (routeError.message.toLowerCase().includes('dynamically imported module') ||
                            routeError.message.toLowerCase().includes('importing a module script failed'))),
                subTitle: routeError.message,
                title: 'Client Error',
            };
        }

        if (isRouteErrorResponse(routeError)) {
            return {
                subTitle: routeError.statusText,
                title: routeError.status,
            };
        }

        return {
            subTitle: '?',
            title: '?',
        };
    }, [routeError]);

    return (
        <section className="flex flex-col items-center gap-y-4 p-8 text-center">
            <span className="text-8xl">
                <Sad />
            </span>

            <h1 className="text-2xl font-medium">{isChunkError ? 'У вас устаревшая версия страницы' : title}</h1>

            <h2 className="text-lg">{subTitle}</h2>

            <div className="flex items-center justify-center divide-x">
                <button
                    className="px-2"
                    onClick={() => {
                        window.location.reload();
                    }}
                >
                    Обновить страницу
                </button>

                <Link to="/" className="px-2">
                    На главную
                </Link>
            </div>
        </section>
    );
});

export default RouterError;
