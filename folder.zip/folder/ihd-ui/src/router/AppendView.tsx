/**
 * Created by VIATKIN A.A. on 16.02.2024
 */

import {isMatchesHandle} from '@/router/types.ts';
import {Fragment, memo} from 'react';
import {useMatches} from 'react-router-dom';

const AppendView = memo(() => {
    const matches = useMatches();
    return matches
        .filter(isMatchesHandle)
        .map(({handle: {append: Append}, id}) => <Fragment key={id}>{Append && <Append />}</Fragment>);
});

export default AppendView;
