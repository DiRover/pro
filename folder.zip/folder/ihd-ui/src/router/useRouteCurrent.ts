import {useRouteChildren} from '@/router/useRouteChildren.ts';

export default function useRouteCurrent() {
    const {current} = useRouteChildren();
    return current;
}
