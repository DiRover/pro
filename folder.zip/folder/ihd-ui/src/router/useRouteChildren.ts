import useToken from '@/hooks/useToken.ts';
import {useMemo} from 'react';
import {useLoaderData} from 'react-router-dom';

import type {RouteObjectWithHandleSlim} from './types.ts';

import {hasAccess} from '../libs/utils.ts';
import {isHandle} from './types.ts';

const isRouteObjectWithHandleSlim = (routes: unknown): routes is RouteObjectWithHandleSlim[] =>
    Array.isArray(routes) && routes.length > 0 && isHandle(routes[0]);

export function useRouteChildren() {
    const data = useLoaderData();
    const {token} = useToken();
    const privileges = token?.user.group?.privileges.map(({value}) => value);

    const {child, current} = useMemo(() => {
        return Array.isArray(data)
            ? {
                  child: isRouteObjectWithHandleSlim(data[1]) ? data[1] : [],
                  current: isRouteObjectWithHandleSlim(data[0]) ? data[0] : [],
              }
            : {
                  child: [],
                  current: [],
              };
    }, [data]);

    const routes = useMemo(
        () =>
            child
                .filter(({handle}) => handle?.navigation)
                .filter(({handle}) => hasAccess(privileges, handle?.permissions)),
        [privileges, child],
    );

    return {current: current.at(0), routes} as const;
}
