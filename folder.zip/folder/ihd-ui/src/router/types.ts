import type {FC} from 'react';
import type {IndexRouteObject, NonIndexRouteObject, RouteObject, useMatches} from 'react-router-dom';

import {type PrivilegesEnum} from '@generated/auth/model';

export interface Handle {
    append?: FC;
    free?: boolean;
    icon?: FC;

    navigation?: boolean;
    permissions?: PrivilegesEnum[];
    prepend?: FC;

    restrictedWithAuth?: boolean;

    title: string;
}

export type IndexRouteObjectWithHandle = {
    handle?: Handle;
} & Omit<IndexRouteObject, 'children' | 'handle'>;

export type NonIndexRouteObjectWithHandle = {
    children?: (IndexRouteObjectWithHandle | NonIndexRouteObjectWithHandle)[];
    handle?: Handle;
} & Omit<NonIndexRouteObject, 'children' | 'handle'>;

export type RouteObjectWithHandle = IndexRouteObjectWithHandle | NonIndexRouteObjectWithHandle;

export type RouteObjectWithHandleSlim = Pick<RouteObjectWithHandle, 'handle' | 'index' | 'path'>;

export const isHandle = (route: unknown): route is RouteObject | RouteObjectWithHandle =>
    !!route && typeof route === 'object' && 'handle' in route && !!route.handle;

// Matches

type matchUnknownHandle = ReturnType<typeof useMatches>[number];

type matchKnownHandle = {
    handle: Handle;
} & Omit<matchUnknownHandle, 'handle'>;

export const isMatchesHandle = (route: matchKnownHandle | matchUnknownHandle): route is matchKnownHandle =>
    'handle' in route && !!route.handle;
