/**
 * Created by VIATKIN A.A. on 03.04.2023
 */

import useDeepMemo from '@/hooks/useDeepMemo.ts';
import useToken from '@/hooks/useToken.ts';
import {memo, useMemo} from 'react';
import {RouterProvider} from 'react-router-dom';

import getRouter from './router.tsx';
import RouterLoader from './RouterLoader.tsx';

const RouterProviderWrapper = memo(() => {
    const {token} = useToken();
    const group = token?.user.group;
    const privileges = group?.privileges.map(({value}) => value);
    const [privilegesDeep] = useDeepMemo(privileges);
    const isAuth = !!token;

    const router = useMemo(() => getRouter(isAuth, privilegesDeep), [isAuth, privilegesDeep]);

    return <RouterProvider fallbackElement={<RouterLoader />} router={router} />;
});

export default RouterProviderWrapper;
