/**
 * Created by VIATKIN on 21.03.2024
 */

import type {ComponentPropsWithoutRef} from 'react';

import {useRouteChildren} from '@/router/useRouteChildren.ts';
import clsx from 'clsx';
import {memo} from 'react';
import {NavLink} from 'react-router-dom';

const SubNav = memo<ComponentPropsWithoutRef<'ul'>>(({className, ...rest}) => {
    const {routes} = useRouteChildren();

    if (!routes.length) return;

    return (
        <ul
            {...rest}
            className={clsx(className, 'flex items-center gap-x-8 self-end opacity-80 *:border-b-2 *:text-sm')}
        >
            {routes.map(({handle, path}, idx) => (
                <li className="border-b-transparent hover:border-b-primary/20 has-[.active]:border-b-primary" key={idx}>
                    <NavLink
                        className={({isActive, isPending, isTransitioning}) =>
                            clsx(
                                'inline-flex rounded-t-lg py-4',
                                isActive && 'active',
                                (isPending || isTransitioning) && 'radial-gradient',
                            )
                        }
                        end={!path}
                        to={path ?? '.'}
                    >
                        <span>{handle?.title}</span>
                    </NavLink>
                </li>
            ))}
        </ul>
    );
});

export default SubNav;
