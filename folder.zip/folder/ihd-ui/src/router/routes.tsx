import Audit from '@/assets/icons/audit.svg?react';
import RouterError from '@/router/RouterError.tsx';
import {adminSection} from '@/router/sections/adminSection.tsx';
import {configSection} from '@/router/sections/configSection.tsx';
import {contractObligationSection} from '@/router/sections/contractObligationSection.tsx';
import {directoriesSection} from '@/router/sections/directoriesSection.tsx';
import {importFileSection} from '@/router/sections/importFileSection.tsx';
import {journalSection} from '@/router/sections/journalSection.tsx';
import {raoSection} from '@/router/sections/raoSection.tsx';
import {reportSection} from '@/router/sections/reportSection.tsx';
import {settingsSection} from '@/router/sections/settingsSection.tsx';
import {structureSection} from '@/router/sections/structureSection.tsx';
import {uktSection} from '@/router/sections/uktSection.tsx';
import {PrivilegesEnum} from '@generated/auth/model';

import type {RouteObjectWithHandle} from './types.ts';

const appRoutes: RouteObjectWithHandle[] = [
    {
        children: [
            {
                handle: {free: true, title: 'О системе'},
                lazy: () => import('../entities/misc/PageAbout.tsx'),
                path: 'about',
            },
            {
                handle: {free: true, restrictedWithAuth: true, title: 'Авторизация'},
                lazy: () => import('../entities/auth/PageLogin.tsx'),
                path: 'login',
            },
            {
                handle: {title: 'Выход'},
                lazy: () => import('../entities/auth/PageLogout.tsx'),
                path: 'logout',
            },
            {
                handle: {title: 'Главная'},
                index: true,
                lazy: () => import('../entities/misc/Home.tsx'),
            },
            importFileSection,
            adminSection,
            directoriesSection,
            contractObligationSection,
            structureSection,
            uktSection,
            raoSection,
            journalSection,
            configSection,
            reportSection,
            {
                handle: {icon: Audit, navigation: true, permissions: [PrivilegesEnum.USERS_MANAGE], title: 'Аудит'},
                lazy: () => import('../entities/audit/Page.tsx'),
                path: 'audit',
            },
            settingsSection,
            {
                handle: {title: 'Профиль'},
                lazy: () => import('../entities/profile/PageProfile.tsx'),
                path: 'profile',
            },
        ],
        errorElement: <RouterError />,
        handle: {free: true, title: 'IHD'},
        lazy: () => import('../App.tsx'),
        path: '/',
    },
];

export default appRoutes;
