/**
 * Created by VIATKIN A.A. on 27.04.2023
 */

import {memo, useEffect} from 'react';
import {useNavigate, useSearchParams} from 'react-router-dom';

export type reason = 'no-auth' | 'not-enough-permission' | 'restricted-with-auth';

const BASE = '/';

const PageRedirect = memo<{reason: reason}>(({reason}) => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const from = searchParams.get('from');

    useEffect(() => {
        switch (reason) {
            case 'restricted-with-auth':
                navigate(from ?? BASE);
                break;

            case 'no-auth':
                window.location.href = `/login?${
                    window.location.pathname !== BASE && window.location.pathname !== '/logout'
                        ? new URLSearchParams({
                              from: window.location.pathname,
                          }).toString()
                        : ''
                }`;
                break;
        }
    }, [from, navigate, reason]);

    if (reason !== 'not-enough-permission') return null;

    return (
        <section className="flex flex-col items-center gap-y-4 p-8 text-center">
            <span className="text-8xl">⛔️</span>

            <h1 className="text-2xl font-medium">Нет доступа</h1>
        </section>
    );
});

export default PageRedirect;
