import type {ThemeConfig} from 'antd';

export const theme = {
    token: {
        borderRadius: 4,
        colorPrimary: '#205dc1',
        colorText: '#323232',
        // colorTextSecondary: '#fcfcfc',
        // fontFamily: '"IBM Plex Sans", sans-serif',
    },
} satisfies ThemeConfig;
