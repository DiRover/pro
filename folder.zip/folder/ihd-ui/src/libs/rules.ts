import type {FormListProps, Rule} from 'antd/es/form';

// Common
export const onlyDigits = {
    message: 'Допустимы только цифры',
    pattern: /^\d*$/gi,
} satisfies Rule;

export const onlyLatin = {
    message: 'Допустимы только латинские символы',
    pattern: /^[a-z]*$/gi,
} satisfies Rule;

export const onlySlavic = {
    message: 'Допустимы только кириллические символы',
    pattern: /^[а-яё]*$/gi,
} satisfies Rule;

export const moreThenZero = {
    validator(_, value?: number) {
        return new Promise((resolve, reject) => {
            if (typeof value === 'number' && value <= 0) {
                reject(new Error('Нельзя 0'));
            } else {
                resolve('');
            }
        });
    },
} satisfies Rule;

type ValidatorRule = Required<FormListProps>['rules'][number];

export const minLengthArray: ValidatorRule = {
    validator: async (_: unknown, names?: unknown[]) => {
        if (!names || names.length < 1) {
            return Promise.reject(new Error('Необходим хотя бы 1 элемент'));
        }
    },
};
