export const MINUTE = 60_000;

export const FIVE_MINUTE = 300_000;

export const HOUR = 3_600_000;

export const DAY = 86_400_000;

export const WEEK = 604_800_000;

export const DECIMAL_SEPARATOR: ',' | '.' = ',';

export const LEMNISCATE = '∞';
