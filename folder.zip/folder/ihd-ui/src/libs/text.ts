export const NO_DATA = 'N/A';
