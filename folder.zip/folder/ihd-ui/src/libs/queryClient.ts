import type {QueryFunction} from '@tanstack/react-query';

import {QueryClient} from '@tanstack/react-query';
import axios from 'axios';

const queryFn: QueryFunction = async ({queryKey, signal}) => {
    let url = '';
    let params = {};

    const [maybeUrl, maybeParams] = queryKey;
    if (typeof maybeUrl === 'string') url = maybeUrl;
    if (maybeParams && typeof maybeParams === 'object') params = maybeParams;

    return await axios.get(url, {
        params,
        signal,
    });
};

export const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            queryFn,
            retry: import.meta.env.DEV ? false : 2,
            staleTime: 5 * 1000,
        },
    },
});
