import type {FormProps} from 'antd';

export const validateMessages = {
    string: {
        len: '${label} должен быть ${len} символов',
    },
    types: {
        integer: '${label} должно быть целым числом',
    },
} satisfies Required<FormProps>['validateMessages'];
