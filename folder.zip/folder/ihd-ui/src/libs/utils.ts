import type {HTTPError, HTTPValidationError, PrivilegesEnum} from '@generated/auth/model';
import type {UploadFile} from 'antd';
import type {UploadChangeParam} from 'antd/es/upload';

export type APIError = HTTPError | HTTPValidationError;

export type Exception = APIError | Error | string;

export type Editable<Instance> = {
    -readonly [Key in keyof Instance]: Instance[Key] extends unknown[] ? Editable<Instance[Key]> : Instance[Key];
};

const isDetailExp = (exp?: unknown): exp is APIError => exp !== null && typeof exp === 'object' && 'detail' in exp;

export function getTextError(exp?: unknown): string {
    const text = 'Unknown error';

    if (!exp) return text;

    if (typeof exp === 'string') return exp;

    if (exp instanceof Error) return exp.message;

    if (isDetailExp(exp)) {
        return typeof exp.detail === 'string' ? exp.detail : (exp.detail?.map(({msg}) => msg).join('; ') ?? text);
    }

    return text;
}

export function hasAccess(hasPermissions?: PrivilegesEnum[], checkPermissions?: PrivilegesEnum[]) {
    if (!hasPermissions && !checkPermissions) return true;

    if (!hasPermissions) return false;

    return checkPermissions ? hasPermissions.some(p => checkPermissions.includes(p)) : true;
}

export function sleep(delay: number, signal: AbortSignal): Promise<void> {
    return new Promise((resolve, reject) => {
        const t = window.setTimeout(() => {
            resolve();
        }, delay);
        signal.addEventListener(
            'abort',
            () => {
                clearTimeout(t);
                reject(new Error('Aborted'));
            },
            {once: true},
        );
    });
}

export function stringToHslColor(str: string, s = 60, l = 60): string {
    const {length} = str;
    let hash = 0;

    for (let i = 0; i < length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }

    const h = hash % 360;

    return `hsl(${h}, ${s}%, ${l}%)`;
}

export function sizeFile(value: number, fixed = 1): string {
    if (Number.isNaN(value)) return '?';

    const suffix = ['б', 'Кб', 'Мб', 'Гб', 'Тб', 'Пб', 'Эб'];
    const countSuffix = suffix.length;

    let v = value;
    let k = 0;

    while (v >= 1024 && k < countSuffix - 1) {
        v /= 1024;
        k++;
    }

    return `${v.toFixed(fixed)}${suffix[k]}`;
}

export const normFile = (e: UploadChangeParam | UploadFile[]) => {
    if (Array.isArray(e)) {
        return e;
    }
    return e.fileList;
};

export function checkValues(value: unknown): boolean {
    if (typeof value === 'undefined' || value === null) return false;
    if (typeof value === 'boolean') return true;
    if (typeof value === 'number') return true;
    if (typeof value === 'bigint') return true;
    if (typeof value === 'string' && value.length > 0) return true;
    if (typeof value === 'symbol') return true;
    if (Array.isArray(value) && value.length > 0) return true;

    return typeof value === 'object' ? Object.values(value).some(v => checkValues(v)) : false;
}
