import Header from '@/components/common/Header.tsx';
import {useTokenRefresh} from '@/hooks/useTokenRefresh.ts';
import Meta from '@/router/Meta.tsx';
import RouterLoader from '@/router/RouterLoader.tsx';
import {Suspense, lazy} from 'react';
import {Outlet, useNavigation} from 'react-router-dom';

const UploadViewer = lazy(() => import('@/entities/mdb/upload/UploadViewer.tsx'));

export function Component() {
    const {state} = useNavigation();

    const {isExpired} = useTokenRefresh();

    return (
        <>
            <Header />
            {!isExpired && (
                <>
                    <Outlet />
                    <Suspense fallback={null}>
                        <UploadViewer />
                    </Suspense>
                </>
            )}
            <Meta />
            {state === 'loading' && <RouterLoader />}
        </>
    );
}
