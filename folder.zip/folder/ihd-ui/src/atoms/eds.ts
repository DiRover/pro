import type {CertListItemInterface, CertificateInfoInterface, InitResultInterface} from 'ruscryptojs';

import {atom, atomFamily, selector} from 'recoil';
import {CryptoPro} from 'ruscryptojs';

const cryptopro = new CryptoPro();

export const edsInitAtom = atom<InitResultInterface>({
    default: cryptopro.init(),
    key: 'edsInitAtom',
});

export const listCertificatesSelector = selector<CertListItemInterface[]>({
    get: async ({get}) => {
        const init = get(edsInitAtom);
        return init.version ? await cryptopro.listCertificates() : [];
    },
    key: 'listCertificatesSelector',
});

export const detailsCertificatesAtom = atomFamily<CertificateInfoInterface, string>({
    default: thumbprint => cryptopro.certificateInfo(thumbprint),
    key: 'detailsCertificatesAtom',
});
