import type {PaginationParams} from '@/components/pagination/types.ts';
import type {Key} from 'react';

import {checkValues} from '@/libs/utils.ts';
import {atomFamily, selectorFamily} from 'recoil';

// presets

export const defaultPaginationParams = {
    page_number: 1,
    page_size: 10,
} satisfies PaginationParams;

// atoms & selectors

export const paginationParamsAtom = atomFamily<PaginationParams, string>({
    default: () => defaultPaginationParams,
    key: 'paginationParamsAtom',
});

const paginationFilterAtom = atomFamily<unknown, string>({
    default: () => ({}),
    key: 'paginationFilterAtom',
});

export const paginationSelectionAtom = atomFamily<Key[], string>({
    default: () => [],
    key: 'paginationSelectionAtom',
});

export const paginationFilterHasValueSelector = selectorFamily<boolean, string>({
    get:
        url =>
        ({get}) => {
            return checkValues(get(paginationFilterAtom(url)));
        },
    key: 'paginationFilterHasValueSelector',
});

export const paginationFilterSelector = selectorFamily<unknown, string>({
    get:
        url =>
        ({get}) =>
            get(paginationFilterAtom(url)),
    key: 'paginationFilterSelector',
    set:
        url =>
        ({set}, newValue) => {
            set(paginationFilterAtom(url), newValue);
            set(paginationParamsAtom(url), prevValue => ({...prevValue, page_number: 1}) satisfies PaginationParams);
        },
});
