import type {LoginResponse} from '@generated/auth/model';

import axios from 'axios';
import {DefaultValue, atom, selector} from 'recoil';

const storeName = 'ihd_token';

function getParsed(raw: null | string): LoginResponse | null {
    try {
        const parsed = raw ? (JSON.parse(raw) as LoginResponse) : null;

        if (parsed) {
            if (parsed.refresh_token_expires * 1000 <= Date.now()) {
                throw new Error('Token is expired');
            }

            axios.defaults.headers.common.Authorization = `Bearer ${parsed.access_token}`;
            return parsed;
        }

        return null;
    } catch {
        localStorage.removeItem(storeName);
        return null;
    }
}

function getDefaultToken(): LoginResponse | null {
    const acc = localStorage.getItem(storeName);
    return getParsed(acc);
}

const bc = new BroadcastChannel('main');

const tokenAtom = atom<LoginResponse | null>({
    default: getDefaultToken(),
    effects: [
        () => {
            const handler = () => {
                if (!document.hasFocus()) {
                    window.location.reload();
                }
            };
            bc.addEventListener('message', handler);

            return () => {
                bc.removeEventListener('message', handler);
            };
        },
    ],
    key: 'tokenAtom',
});

export const tokenSelector = selector<LoginResponse | null>({
    get: ({get}) => get(tokenAtom),
    key: 'tokenSelector',
    set: ({set}, newValue) => {
        if (newValue && !(newValue instanceof DefaultValue)) {
            localStorage.setItem(storeName, JSON.stringify(newValue));
            axios.defaults.headers.common.Authorization = `Bearer ${newValue.access_token}`;
            bc.postMessage('login');
        } else {
            sessionStorage.clear();
            localStorage.removeItem(storeName);
            delete axios.defaults.headers.common.Authorization;
            bc.postMessage('logout');
        }

        set(tokenAtom, newValue);
    },
});
