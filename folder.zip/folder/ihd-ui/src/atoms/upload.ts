import {atom} from 'recoil';

export const uploadAtom = atom<File[]>({
    default: [],
    key: 'uploadAtom',
});
