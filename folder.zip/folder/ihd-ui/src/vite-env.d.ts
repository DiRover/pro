/// <reference types="vite/client" />
/// <reference types="vite-plugin-svgr/client" />

interface ImportMetaEnv {
    readonly VITE_GIT_COMMIT: string;
    readonly VITE_GIT_TAG: string;
    readonly VITE_GIT_TIMESTAMP: string;
}

interface ImportMeta {
    readonly env: ImportMetaEnv;
}

declare const __BUILD_DATE__: string;
declare const __VERSION__: string;
