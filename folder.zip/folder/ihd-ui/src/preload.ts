window.addEventListener(
    'load',
    () => {
        window.addEventListener('vite:preloadError', () => {
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        });
    },
    {once: true},
);
