import 'typings/i18next';
import {resources} from '../src/i18n/i18n';

declare module 'typings/i18next' {
    interface CustomTypeOptions {
        defaultNS: 'common';
        resources: (typeof resources)['ru'];
    }
}
