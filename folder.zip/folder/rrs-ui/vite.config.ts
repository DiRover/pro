import react from '@vitejs/plugin-react-swc';
import {defineConfig} from 'vite';

const version = process.env.npm_package_version;
const buildDate = Date.now();

const devTarget = 'rrs-dev.element-soft.com';

export default defineConfig({
    plugins: [react()],
    server: {
        port: 3000,
        proxy: {
            '/api': {
                target: `https://${devTarget}`,
                changeOrigin: true,
                secure: true,
            },
            '/websocket': {
                target: `wss://${devTarget}`,
                changeOrigin: true,
                secure: true,
                ws: true,
            },
        },
    },
    define: {
        __APP_VERSION__: `"${version}"`,
        __BUILD_DATE__: `"${buildDate}"`,
    },
});
