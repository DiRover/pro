/// <reference types="vite/client" />

declare const __APP_VERSION__: string;
declare const __BUILD_DATE__: string;

interface ImportMetaEnv {
    readonly VITE_GIT_COMMIT: string;
    readonly VITE_GIT_BRANCH: string;
}

interface ImportMeta {
    readonly env: ImportMetaEnv;
}
