import type {ThemeConfig} from 'antd/es/config-provider/context';

export const theme = {
    token: {
        colorPrimary: '#207ca3',
        colorSuccess: '#52c41a',
        colorWarning: '#e29832',
        colorError: '#f5222d',
        fontFamily: "'Trebuchet MS', sans-serif",
    },
} satisfies ThemeConfig;
