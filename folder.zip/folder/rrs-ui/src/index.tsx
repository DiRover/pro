/**
 * Created by VIATKIN A.A. on 23.12.2019
 */

import * as dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';
import isBetween from 'dayjs/plugin/isBetween';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import localizedFormat from 'dayjs/plugin/localizedFormat';
import relativeTime from 'dayjs/plugin/relativeTime';
import timezone from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';
import {Suspense} from 'react';
import {createRoot} from 'react-dom/client';
import {Provider as ReduxProvider} from 'react-redux';
import {BrowserRouter} from 'react-router-dom';

import App from './App';
import ConfigProviderWrapper from './components/Utils/ConfigProviderWrapper';
import SuspenseErrorCatcher from './components/Utils/SuspenseErrorCatcher';
import createStore from './store/store';
import 'dayjs/locale/ru';
import 'dayjs/locale/en-gb';
import 'dayjs/locale/pl';

import './i18n/i18n';

dayjs.extend(relativeTime);
dayjs.extend(localizedFormat);
dayjs.extend(isBetween);
dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);
dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(duration);
dayjs.locale('ru');

const store = createStore();

const root = createRoot(document.getElementById('app') as HTMLElement);

root.render(
    <ReduxProvider store={store}>
        <BrowserRouter>
            <SuspenseErrorCatcher>
                <Suspense fallback={null}>
                    <ConfigProviderWrapper>
                        <App />
                    </ConfigProviderWrapper>
                </Suspense>
            </SuspenseErrorCatcher>
        </BrowserRouter>
    </ReduxProvider>,
);
