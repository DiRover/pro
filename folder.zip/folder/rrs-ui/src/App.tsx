/**
 * Created by VIATKIN A.A. on 23.12.2019
 */

import {Global, css} from '@emotion/react';
import styled from '@emotion/styled';
import {lazy, Suspense, memo} from 'react';
import {useDispatch} from 'react-redux';
import {all} from 'redux-saga/effects';

import 'antd/dist/reset.css';

import AxiosInterceptorAccess from './components/Utils/AxiosInterceptorAccess';
import SuspenseErrorCatcher from './components/Utils/SuspenseErrorCatcher';
import useAuth from './hooks/useAuth';
import useLS from './hooks/useLS';
import useTokenUpdate from './hooks/useTokenUpdate';
import RouterWrapper from './router/RouterWrapper';
import {setAuth, logout} from './store/account/actions';
import {Token} from './store/account/types';
import {sagaMiddleware} from './store/store';

const Header = lazy(() => import('./components/Layout/Header'));
const AxiosInterceptorMessage = lazy(() => import('./components/Presentation/AxiosInterceptorMessage'));
const OnLine = lazy(() => import('./components/Utils/OnLine'));

import {theme} from './theme';

let hasNotificationSagas = false;

const Connector = lazy(() =>
    import('./entities/notification/Connector').then(module => {
        if (!hasNotificationSagas) {
            hasNotificationSagas = true;
            sagaMiddleware.run(function* () {
                yield all([...module.sagas]);
            });
        }
        return module;
    }),
);

const globalStyle = css`
    :root {
        --main: ${theme.token.colorPrimary};
        --second: ${theme.token.colorWarning};
        --error: ${theme.token.colorError};
        --success: ${theme.token.colorSuccess};
        --dark: #211e2f;
        --header-height: 52px;
    }

    body {
        background: #f0f2f5;
        font-family: 'Trebuchet MS', sans-serif;
        font-size: 14px;
    }

    body.hidden {
        overflow: hidden;
    }

    .ant-descriptions .ant-descriptions-item-label {
        color: #a4a4a4;
    }

    .ant-descriptions span.ant-descriptions-item-content {
        padding-bottom: 1rem;
    }

    .ant-popover.popover-no-padding .ant-popover-title {
        padding: 0.5rem 0.5rem 0;
    }

    .ant-popover.popover-no-padding .ant-popover-inner {
        padding: 0;
    }

    .ant-form {
        overflow: hidden;
    }

    .ant-form .ant-form-item-explain-error {
        color: var(--error);
    }

    .operation-select-dropdown-menu {
        max-height: 320px;
        overflow-y: auto;
        overscroll-behavior: none;
    }
`;

const messageStyleLight = css`
    .ant-message .message-error {
        & .ant-message-notice-content {
            background: var(--error);
            color: #ffffff;
        }

        & .ant-message-error .anticon {
            color: #ffffff;
        }
    }
`;

const messageStyleDark = css`
    .ant-message .message-error {
        & .ant-message-notice-content {
            background: var(--dark);
            color: #ffffff;
        }

        & .ant-message-error .anticon {
            color: #ffffff;
        }
    }
`;

const TextUpdate = styled.h3`
    text-align: center;
`;

const App = memo(() => {
    const dispatch = useDispatch();

    useLS<Token>('account', token => {
        if (token) {
            dispatch(setAuth(token));
        } else {
            dispatch(
                logout({
                    quiet: true,
                }),
            );
        }
    });

    const [needBlock] = useTokenUpdate();

    const isAuth = useAuth();

    return (
        <>
            <Global styles={globalStyle} />
            <Global styles={isAuth ? messageStyleLight : messageStyleDark} />

            <SuspenseErrorCatcher>
                <Suspense fallback={null}>
                    <OnLine />
                </Suspense>
            </SuspenseErrorCatcher>

            <AxiosInterceptorAccess />

            <SuspenseErrorCatcher>
                <Suspense fallback={null}>
                    <AxiosInterceptorMessage />
                </Suspense>
            </SuspenseErrorCatcher>

            {needBlock ? (
                <TextUpdate>Идёт обновление токена, пожалуйста, подождите.</TextUpdate>
            ) : (
                <>
                    {isAuth && (
                        <SuspenseErrorCatcher>
                            <Suspense fallback={null}>
                                <Header />
                            </Suspense>
                        </SuspenseErrorCatcher>
                    )}

                    {isAuth && (
                        <SuspenseErrorCatcher>
                            <Suspense fallback={null}>
                                <Connector />
                            </Suspense>
                        </SuspenseErrorCatcher>
                    )}

                    <RouterWrapper />
                </>
            )}
        </>
    );
});

export default App;
