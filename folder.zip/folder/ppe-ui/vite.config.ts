import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';
import svgr from 'vite-plugin-svgr';

const buildDate = Date.now();
const version = process.env.npm_package_version;
const appName = 'PPE';
const devTarget = 'ppe-dev.element-soft.com';

export default defineConfig({
    define: {
        __BUILD_DATE__: `"${buildDate}"`,
        __SYSTEM__: `"${appName}"`,
        __VERSION__: `"${version}"`,
    },
    plugins: [svgr(), react()],
    resolve: {
        alias: {
            '@assets': path.resolve(__dirname, './src/assets'),
            '@components': path.resolve(__dirname, './src/components'),
            '@generated': path.resolve(__dirname, './src/__generated__'),
            '@hooks': path.resolve(__dirname, './src/hooks'),
        },
    },
    server: {
        port: 3000,
        proxy: {
            '/api': {
                changeOrigin: true,
                secure: true,
                target: `https://${devTarget}`,
            },
            '/graphql': {
                changeOrigin: true,
                secure: false,
                target: `http://${devTarget}:8090`,
            },
            '/ws': {
                target: `ws://${devTarget}:8090`,
                ws: true,
            },
        },
    },
});
