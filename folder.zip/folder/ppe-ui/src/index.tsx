/**
 * Created by ROVENSKIY D.A. on 18.07.2023
 */

import type {ConfigProviderProps} from 'antd/es/config-provider';

import {StyleProvider} from '@ant-design/cssinjs';
import ApolloProviderWrapper from '@components/Utils/ApolloProviderWrapper.tsx';
import {App as AppAntd, ConfigProvider} from 'antd';
import ru_RU from 'antd/locale/ru_RU';
import * as dayjs from 'dayjs';
import 'dayjs/locale/ru';
import duration from 'dayjs/plugin/duration';
import localizedFormat from 'dayjs/plugin/localizedFormat';
import relativeTime from 'dayjs/plugin/relativeTime';
import timezone from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';
import {StrictMode} from 'react';
import ReactDOM from 'react-dom/client';
import {RecoilRoot} from 'recoil';

import RouterProviderWrapper from './routes/RouterProviderWrapper.tsx';
import './style/global.css';
import theme from './style/theme.ts';

dayjs.locale('ru');
dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(localizedFormat);
dayjs.extend(relativeTime);
dayjs.extend(duration);

const configProviderForm: ConfigProviderProps['form'] = {colon: false};

ReactDOM.createRoot(document.getElementById('app') as HTMLElement).render(
    <StrictMode>
        <RecoilRoot>
            <AppAntd>
                <ApolloProviderWrapper>
                    <ConfigProvider form={configProviderForm} locale={ru_RU} theme={theme}>
                        <StyleProvider hashPriority="high">
                            <RouterProviderWrapper />
                        </StyleProvider>
                    </ConfigProvider>
                </ApolloProviderWrapper>
            </AppAntd>
        </RecoilRoot>
    </StrictMode>,
);
