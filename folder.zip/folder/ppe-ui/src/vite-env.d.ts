/// <reference types="vite/client" />
/// <reference types="vite-plugin-svgr/client" />

declare const __SYSTEM__: string;
declare const __VERSION__: string;
declare const __BUILD_DATE__: string;
