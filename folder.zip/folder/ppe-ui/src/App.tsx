/**
 * Created by ROVENSKIY D.A. on 18.07.2023
 */

import Header from '@components/Header.tsx';
import SuspenseLoader from '@components/Presentation/SuspenseLoader.tsx';
import useRefresher from '@hooks/useRefresher.ts';
import {Button, Result} from 'antd';
import {memo} from 'react';
import {Outlet, useNavigation} from 'react-router-dom';

import Meta from './routes/Meta.tsx';

export const Component = memo(() => {
    const {expired, logout} = useRefresher();
    const {state} = useNavigation();

    return (
        <>
            {expired ? (
                <Result
                    extra={
                        <Button onClick={() => logout(true)} type="primary">
                            Выход
                        </Button>
                    }
                    title="Токен истёк"
                />
            ) : (
                <>
                    <Header />

                    <Outlet />
                </>
            )}

            {state === 'loading' && <SuspenseLoader />}

            <Meta />
        </>
    );
});
