module.exports = {
    env: {browser: true, es2023: true},
    extends: [
        'eslint:recommended',
        'plugin:@typescript-eslint/recommended',
        'plugin:react/recommended',
        'plugin:react-hooks/recommended',
        'plugin:prettier/recommended',
        'plugin:jsx-a11y/recommended',
        'plugin:tailwindcss/recommended',
        'plugin:perfectionist/recommended-natural',
    ],
    parser: '@typescript-eslint/parser',
    parserOptions: {ecmaVersion: 'latest', sourceType: 'module'},
    plugins: [
        'prettier',
        'react-refresh',
        'react',
        'react-hooks',
        '@typescript-eslint',
        'jsx-a11y',
        'tailwindcss',
        'perfectionist'
    ],
    rules: {
        'react-refresh/only-export-components': [2],

        '@typescript-eslint/consistent-type-imports': [2],
        '@typescript-eslint/ban-ts-comment': [1],
        '@typescript-eslint/no-explicit-any': [2],
        '@typescript-eslint/no-unused-vars': [2],
        '@typescript-eslint/array-type': [
            2,
            {
                default: 'generic',
            },
        ],

        'react-hooks/rules-of-hooks': [2],
        'react-hooks/exhaustive-deps': [2],

        'no-restricted-imports': [
            'error',
            {
                paths: [
                    {
                        name: 'react',
                        importNames: ['default'],
                        message: "Dont use 'import React from 'react''.",
                    },
                    {
                        name: 'react-router',
                        message: 'Please use import from react-router-dom instead.',
                    },
                    {
                        name: 'antd',
                        importNames: ['notification', 'message'],
                        message: 'Please use `const {notification, message} = useApp();` instead.',
                    },
                ],
            },
        ],

        'react/jsx-boolean-value': [2],
        'react/jsx-curly-brace-presence': [2],
        'react/self-closing-comp': [2],
        'react/react-in-jsx-scope': [0],
        'react/prop-types': [0],
        'react/display-name': [0],

        'no-console': [2],
    },
    settings: {
        react: {
            version: 'detect',
        },
        tailwindcss: {
            config: 'tailwind.config.js',
        },
    },
};
