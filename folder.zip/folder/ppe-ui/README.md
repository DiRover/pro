# Программно-технический комплекс по мониторингу средств индивидуальной защиты на предприятиях

## License
[UNLICENSED](https://choosealicense.com/licenses/unlicense/)