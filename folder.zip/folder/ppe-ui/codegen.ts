import type {CodegenConfig} from '@graphql-codegen/cli';

const config: CodegenConfig = {
    schema: 'http://ppe-dev.element-soft.com:8090/graphql',
    documents: ['src/**/*.{ts,tsx}'],
    generates: {
        './src/__generated__/': {
            preset: 'client',
            plugins: [],
            presetConfig: {
                gqlTagName: 'gql',
            },
        },
    },
    hooks: {afterAllFileWrite: ['prettier --write']},
    ignoreNoDocuments: true,
};

export default config;
