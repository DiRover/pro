/** @type {import('tailwindcss').Config} */
export default {
    content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
    theme: {
        extend: {
            colors: {
                primary: 'rgb(var(--color-primary) / <alpha-value>)',
                accent: 'rgb(var(--color-accent) / <alpha-value>)',
            },
            transitionTimingFunction: {
                spring: 'cubic-bezier(0.1, 0.5, 0.5, 1.25)',
            },
            lineHeight: {
                inherit: 'inherit',
            },
        },
    },
    plugins: [],
};
